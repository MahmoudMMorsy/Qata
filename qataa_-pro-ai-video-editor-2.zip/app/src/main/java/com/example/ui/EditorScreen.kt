package com.example.ui

import android.content.Context
import android.content.Intent
import android.util.Log
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.media.CinematicFilter
import com.example.media.CompressionLevel
import com.example.media.SplitMode
import com.example.ui.theme.*
import com.example.viewmodel.EditorUiState
import com.example.viewmodel.MediaMetadata
import com.example.viewmodel.VideoEditorViewModel
import com.example.viewmodel.formatTime
import kotlinx.coroutines.delay
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: VideoEditorViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()

    var showSplashScreen by remember { mutableStateOf(true) }
    var splashProgress by remember { mutableStateOf(0f) }
    var activeStatusIndex by remember { mutableStateOf(0) }
    var selectedTabIdx by remember { mutableStateOf(0) }
    var workspaceMode by remember { mutableStateOf(0) } // 0: Premiere, 1: AI, 2: Cinema/Scopes
    var activeNavTab by remember { mutableStateOf("EDITOR") }

    val statusTexts = listOf(
        "جاري فحص محرك المونتاج الذكي قَطْع v3.5...",
        "التحقق من مسرع رسوميات GPU محلياً للتصدير فائق السرعة...",
        "تهيئة مسارات معالجة الفيديو بدقة 4K Ultra HD...",
        "تنسيق المونتاج الفوري وتنشيط تأثيرات الحركة الذكية...",
        "تحضير الفلاتر السينمائية ولوحات الألوان الإبداعية...",
        "جاري تنشيط ميزة الإزالة الذكية للأصوات وتخميد الضوضاء...",
        "تأمين بيئة المونتاج الخالية من النت والإعلانات... جاهز للبدء!"
    )

    // Animated loading progress
    LaunchedEffect(showSplashScreen) {
        if (showSplashScreen) {
            val totalSteps = 100
            for (step in 1..totalSteps) {
                delay(30)
                splashProgress = step / 100f
                if (step % 14 == 0) {
                    activeStatusIndex = (activeStatusIndex + 1) % statusTexts.size
                }
            }
            showSplashScreen = false
        }
    }

    // File Picker for offline video & audio files
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { selectedUri ->
            retrieveMediaMetadata(context, selectedUri) { name, isVideo, duration, size ->
                viewModel.setCustomMedia(selectedUri, name, isVideo, duration, size)
            }
        }
    }

    // Target folder picker for custom export directory
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                Log.e("EditorScreen", "Failed to persist SAF folder permission", e)
            }
            
            // Get user-friendly name of the chosen folder
            var folderName = "مجلد مخصص"
            try {
                val docFile = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, uri)
                if (docFile != null && docFile.name != null) {
                    folderName = docFile.name!!
                }
            } catch (e: Exception) {
                // Keep default
            }
            viewModel.setCustomExportFolder(uri, folderName)
        }
    }

    // Handle incoming snackbar/info messages
    LaunchedEffect(uiState.infoMessage) {
        uiState.infoMessage?.let { msg ->
            delay(3000)
            viewModel.dismissMessage()
        }
    }

    if (showSplashScreen) {
        // IMMERSIVE CINEMATIC SPLASH SCREEN (Adobe Premiere / DaVinci Style)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF090A0D))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth().fillMaxHeight()
            ) {
                // Wide Cinematic Logo Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .wrapContentHeight()
                ) {
                    Image(
                        painter = painterResource(id = com.example.R.drawable.img_qataa_splash_1783284037961),
                        contentDescription = "بانر البدء",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(
                                BorderStroke(1.5.dp, Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.6f), TrackVideoColor.copy(alpha = 0.6f)))),
                                RoundedCornerShape(16.dp)
                            ),
                        contentScale = ContentScale.Crop
                    )
                    
                    // Translucent Badge Overlay at Top Left
                    Surface(
                        color = Color.Black.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(topStart = 16.dp, bottomEnd = 12.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = "الإصدار ٣.٥ الممتاز ✨",
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    // Skip button in Splash
                    TextButton(
                        onClick = { showSplashScreen = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White.copy(alpha = 0.8f)),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Text(text = "تخطي التحميل ⚡", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // App info headers
                Text(
                    text = "قَطْع — مُعالج ومُحرر الفيديو والذكاء الاصطناعي",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = "برنامج تحرير فيديو احترافي ومحلي ١٠٠٪ بدون إنترنت",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                )

                // High-fidelity progress indicator with custom neon glow background
                Column(
                    modifier = Modifier.fillMaxWidth(0.85f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Current progress percent
                        Text(
                            text = "${(splashProgress * 100).toInt()}%",
                            color = NeonCyan,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                        
                        // Action status Text
                        Text(
                            text = "جاري التحميل...",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Neon bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .background(Color(0xFF131722), RoundedCornerShape(3.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(splashProgress)
                                .fillMaxHeight()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(TrackVideoColor, NeonCyan)
                                    ),
                                    RoundedCornerShape(3.dp)
                                )
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Running dynamic task subtitle
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedContent(
                            targetState = statusTexts[activeStatusIndex],
                            transitionSpec = {
                                fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                            },
                            label = "status_anim"
                        ) { text ->
                            Text(
                                text = text,
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))

                // Capabilities indicators footer
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CapabilityBadge(icon = Icons.Default.Bolt, label = "معالج GPU محلي")
                    Box(modifier = Modifier.size(4.dp).background(TextSecondary, CircleShape))
                    CapabilityBadge(icon = Icons.Default.Build, label = "الذكاء الاصطناعي")
                    Box(modifier = Modifier.size(4.dp).background(TextSecondary, CircleShape))
                    CapabilityBadge(icon = Icons.Default.Lock, label = "آمن ١٠٠٪")
                }
            }
        }
    } else {
        // MAIN WORKSPACE INTERFACE
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Img Avatar Logo from the user's gorgeous icon
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(NeonCyan, TrackVideoColor))),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .shadow(6.dp, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = com.example.R.drawable.img_qataa_logo_1783284023095),
                                    contentDescription = "شعار قطع",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Column {
                                Text(
                                    text = "قَطْع الاحترافي",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "محرر ومعالج 4K الذكي محلياً",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    },
                    actions = {
                        // Fully local offline status tag
                        Surface(
                            color = SuccessGreen.copy(alpha = 0.15f),
                            contentColor = SuccessGreen,
                            shape = RoundedCornerShape(50.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .size(6.dp)
                                        .background(SuccessGreen, CircleShape)
                                )
                                Text(
                                    text = "مسرع GPU نشط",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Reset button
                        IconButton(
                            onClick = { viewModel.loadDemoAsset() },
                            modifier = Modifier.testTag("reset_demo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحميل الملف التجريبي",
                                tint = TextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkSlateBackground,
                        titleContentColor = Color.White
                    )
                )
            },
            containerColor = DarkSlateBackground,
            bottomBar = {
                Column {
                    if (activeNavTab == "EDITOR") {
                        BottomExportBar(
                            metadata = uiState.currentMedia,
                            onExportClick = { viewModel.showExportDialog(true) }
                        )
                    }
                    CyberpunkBottomNavBar(
                        activeTab = activeNavTab,
                        onTabSelected = { activeNavTab = it }
                    )
                }
            },
            modifier = modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
            ) {
                when (activeNavTab) {
                    "EDITOR" -> {
                        Column(
                            modifier = Modifier.fillMaxSize()
                        ) {
                            // 1. FIXED PREVIEW MONITOR (Always visible at the top, DaVinci style)
                            PreviewMonitorWithCinemaScopes(
                                uiState = uiState,
                                cinemaMode = (workspaceMode == 2),
                                onTogglePlay = { viewModel.togglePlayback() },
                                onSeek = { viewModel.seekTo(it) }
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // 2. SCROLLABLE EDITING CONTROL WORKSPACE (Underneath)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .verticalScroll(rememberScrollState())
                                    .padding(horizontal = 8.dp)
                            ) {
                                // Workspace selector chips
                                WorkspaceSelectorChips(
                                    currentMode = workspaceMode,
                                    onModeChange = { mode ->
                                        workspaceMode = mode
                                        // Sync workspace mode to tab indices automatically!
                                        when (mode) {
                                            0 -> selectedTabIdx = 0 // Cut / splits
                                            1 -> selectedTabIdx = 4 // AI controls
                                            2 -> selectedTabIdx = 1 // Color filters
                                        }
                                    }
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                // Timeline Tracks (Trimming and Waveforms)
                                TimelineTracks(
                                    uiState = uiState,
                                    onSeek = { viewModel.seekTo(it) },
                                    onStartChange = { viewModel.setSelectionStart(it) },
                                    onEndChange = { viewModel.setSelectionEnd(it) }
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                // Workspace Control Tabs
                                WorkspaceControlTabs(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    selectedTabIdx = selectedTabIdx,
                                    onTabSelected = { selectedTabIdx = it },
                                    workspaceMode = workspaceMode
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                // Collapsible Source Info Panel
                                SourceFileSelector(
                                    metadata = uiState.currentMedia,
                                    onPickFile = { mediaPickerLauncher.launch("video/*, audio/*") },
                                    onLoadDemo = { viewModel.loadDemoAsset() }
                                )
                                
                                Spacer(modifier = Modifier.height(16.dp))
                            }
                        }
                    }
                    "HOME" -> {
                        HomeView(uiState, viewModel, onStartEditing = { activeNavTab = "EDITOR" })
                    }
                    "PROJECTS" -> {
                        ProjectsView(uiState, viewModel, onOpenProject = { activeNavTab = "EDITOR" })
                    }
                    "RECORD" -> {
                        RecordView(uiState, viewModel)
                    }
                    "STUDIO" -> {
                        StudioView(uiState, viewModel, onOpenProject = { activeNavTab = "EDITOR" })
                    }
                }
                
                // Floating Custom Elegant Message/Toast Overlay
                AnimatedVisibility(
                    visible = uiState.infoMessage != null,
                    enter = fadeIn() + slideInVertically(initialOffsetY = { 50 }),
                    exit = fadeOut() + slideOutVertically(targetOffsetY = { 50 }),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp, start = 16.dp, end = 16.dp)
                ) {
                    Surface(
                        color = SurfaceLight,
                        contentColor = Color.White,
                        shape = RoundedCornerShape(12.dp),
                        tonalElevation = 6.dp,
                        border = BorderStroke(1.dp, PremiereBlue.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "تنبيه",
                                tint = NeonCyan
                            )
                            Text(
                                text = uiState.infoMessage ?: "",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.dismissMessage() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Export Processing Progress Modal Dialog
            if (uiState.showExportDialog) {
                ExportProgressDialog(
                    uiState = uiState,
                    onDismiss = { viewModel.showExportDialog(false) },
                    onStartExport = { viewModel.startExportProcess() },
                    onChooseFolder = { folderPickerLauncher.launch(null) },
                    onClearFolder = { viewModel.clearCustomExportFolder() }
                )
            }
        }
    }
}

@Composable
fun HomeView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel,
    onStartEditing: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Welcoming Hero Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C0E14)),
            border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(NeonCyan, NeonPink))),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "NEO-EDIT",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonPink.copy(alpha = 0.5f),
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.offset(x = (-2).dp, y = (1).dp)
                    )
                    Text(
                        text = "NEO-EDIT",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonCyan.copy(alpha = 0.5f),
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.offset(x = (2).dp, y = (-1).dp)
                    )
                    Text(
                        text = "NEO-EDIT",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "مرحباً بك في مستقبل معالجة المونتاج المحلي والذكي",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onStartEditing,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(0.8f)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.MovieFilter, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text(text = "ابدأ مونتاج فيديو جديد", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Capabilities Grid
        Text(
            text = "المميزات النشطة محلياً",
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.End)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(SurfaceSlate, RoundedCornerShape(12.dp))
                    .border(BorderStroke(1.dp, Color(0xFF161B29)), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.SdCard, contentDescription = null, tint = NeonCyan)
                    Text(text = "معالجة بلا حدود", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "تعديل، قص، وتصدير غير محدود بجودة فائقة.", color = TextSecondary, fontSize = 10.sp)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(SurfaceSlate, RoundedCornerShape(12.dp))
                    .border(BorderStroke(1.dp, Color(0xFF161B29)), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.GraphicEq, contentDescription = null, tint = NeonPink)
                    Text(text = "صوت ذكي محلي", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "إزالة الضوضاء وتضخيم الصوت بالكامل دون إنترنت.", color = TextSecondary, fontSize = 10.sp)
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceSlate, RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Color(0xFF161B29)), RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                    Text(text = "ضغط الفيديو الذكي", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "تقليل الحجم لأكثر من ٨٠٪ مع الحفاظ التام على الدقة الأصلية.", color = TextSecondary, fontSize = 11.sp)
                }
                Icon(imageVector = Icons.Default.Compress, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(36.dp))
            }
        }
    }
}

@Composable
fun ProjectsView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel,
    onOpenProject: () -> Unit
) {
    val sampleProjects = listOf(
        Pair("مقطع النيون الافتراضي.mp4", "منذ ساعتين • 24.5MB"),
        Pair("تسجيل كاميرا السيارة الاحترافي.mov", "أمس • 140.2MB"),
        Pair("مؤثرات الصوت السايكوديلية.mp3", "منذ ٣ أيام • 4.8MB"),
        Pair("تصميم مقدمة يوتيوب بدقة 4K.mp4", "الأسبوع الماضي • 92.1MB")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "المشاريع الأخيرة والمحفوظات",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.End)
        )

        sampleProjects.forEach { proj ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceSlate),
                border = BorderStroke(1.dp, Color(0xFF161B29)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenProject() }
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = null, tint = TextSecondary)
                    
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(text = proj.first, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(text = proj.second, color = TextSecondary, fontSize = 10.sp)
                    }

                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.3f), NeonPink.copy(alpha = 0.3f)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.VideoLibrary, contentDescription = null, tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun RecordView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel
) {
    var isRecording by remember { mutableStateOf(false) }
    var recordTimeSeconds by remember { mutableStateOf(0) }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            while (isRecording) {
                delay(1000)
                recordTimeSeconds++
            }
        } else {
            recordTimeSeconds = 0
        }
    }

    val minutes = recordTimeSeconds / 60
    val seconds = recordTimeSeconds % 60
    val timerStr = String.format("%02d:%02d", minutes, seconds)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "تسجيل واستيراد الكاميرا الذكية",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.End)
        )

        // Camera Simulated Screen
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .border(BorderStroke(2.dp, if (isRecording) NeonPink else NeonCyan), RoundedCornerShape(16.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            // Lens simulator / circles
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val center = Offset(w / 2f, h / 2f)

                // Grid lines
                drawLine(color = Color.White.copy(alpha = 0.15f), start = Offset(w / 3f, 0f), end = Offset(w / 3f, h))
                drawLine(color = Color.White.copy(alpha = 0.15f), start = Offset(2 * w / 3f, 0f), end = Offset(2 * w / 3f, h))
                drawLine(color = Color.White.copy(alpha = 0.15f), start = Offset(0f, h / 3f), end = Offset(w, h / 3f))
                drawLine(color = Color.White.copy(alpha = 0.15f), start = Offset(0f, 2 * h / 3f), end = Offset(w, 2 * h / 3f))

                // Outer and inner target circles
                drawCircle(color = if (isRecording) NeonPink.copy(alpha = 0.1f) else NeonCyan.copy(alpha = 0.1f), radius = 50.dp.toPx(), center = center)
                drawCircle(color = if (isRecording) NeonPink.copy(alpha = 0.3f) else NeonCyan.copy(alpha = 0.3f), radius = 10.dp.toPx(), center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx()))
            }

            // REC Blinking dot and time duration
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (isRecording) {
                    val infiniteTransition = rememberInfiniteTransition(label = "rec_blink")
                    val alpha by infiniteTransition.animateFloat(
                        initialValue = 1f,
                        targetValue = 0f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(500, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "blink"
                    )
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Red.copy(alpha = alpha))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Gray)
                    )
                }
                Text(
                    text = if (isRecording) "REC $timerStr" else "READY",
                    color = if (isRecording) NeonPink else Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Specs Overlay
            Text(
                text = "4K UHD 60FPS • ISO 400",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(14.dp)
            )

            // Bottom Audio Meter
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "BAT: 74%", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf(5, 8, 12, 10, 6, 9, 11, 4, 7, 3).forEach { ht ->
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(if (isRecording) (ht * (1 + Math.random() * 1.5)).dp else ht.dp)
                                .clip(RoundedCornerShape(1.dp))
                                .background(if (isRecording) NeonPink else NeonCyan)
                        )
                    }
                }
            }
        }

        // Recording Button
        Box(
            modifier = Modifier
                .size(70.dp)
                .border(BorderStroke(4.dp, Color.White), CircleShape)
                .padding(6.dp)
                .clip(CircleShape)
                .background(if (isRecording) NeonPink else Color.Red)
                .clickable { isRecording = !isRecording },
            contentAlignment = Alignment.Center
        ) {
            if (isRecording) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(Color.White, RoundedCornerShape(4.dp))
                )
            }
        }
    }
}

@Composable
fun StudioView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel,
    onOpenProject: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "استوديو القوالب والمؤثرات الجاهزة",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.End)
        )

        listOf(
            Triple("قالب ريترو نيون رائع", "Retro Wave Template", NeonPink),
            Triple("مقدمة يوتيوب سينمائية", "Cinematic Intro Preset", NeonCyan),
            Triple("فلاتر تلوين هوليوود", "Hollywood Grading Pack", Color.Yellow),
            Triple("حزمة أصوات السايبربانك", "Cyberpunk SFX Kit", Color(0xFFE91E63))
        ).forEach { pack ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceSlate),
                border = BorderStroke(1.dp, Color(0xFF161B29)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenProject() }
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = null, tint = TextSecondary)
                    
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(text = pack.first, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(text = pack.second, color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(pack.third.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = pack.third)
                    }
                }
            }
        }
    }
}

@Composable
fun CyberpunkBottomNavBar(
    activeTab: String,
    onTabSelected: (String) -> Unit
) {
    val navItems = listOf(
        NavToolItem("HOME", "الرئيسية", Icons.Default.Home),
        NavToolItem("PROJECTS", "المشاريع", Icons.Default.Folder),
        NavToolItem("RECORD", "التسجيل", Icons.Default.RadioButtonChecked),
        NavToolItem("STUDIO", "المعرض", Icons.Default.Videocam),
        NavToolItem("EDITOR", "المحرر الذكي", Icons.Default.ContentCut)
    )

    Surface(
        color = Color(0xFF06070B),
        border = BorderStroke(1.dp, Color(0xFF141A29)),
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEach { item ->
                val isActive = item.key == activeTab
                val color = if (isActive) NeonCyan else TextSecondary

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onTabSelected(item.key)
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (isActive) {
                        Box(
                            modifier = Modifier
                                .width(36.dp)
                                .height(3.dp)
                                .background(NeonCyan, RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp))
                                .shadow(
                                    elevation = 8.dp,
                                    shape = RoundedCornerShape(2.dp),
                                    ambientColor = NeonCyan,
                                    spotColor = NeonCyan
                                )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    } else {
                        Spacer(modifier = Modifier.height(7.dp))
                    }

                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = color,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = item.label,
                        color = color,
                        fontSize = 9.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                        letterSpacing = 0.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

data class NavToolItem(val key: String, val label: String, val icon: ImageVector)

@Composable
fun CapabilityBadge(icon: ImageVector, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
        Text(text = label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun WorkspaceSelectorChips(
    currentMode: Int,
    onModeChange: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .background(SurfaceSlate, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, SurfaceLight), RoundedCornerShape(12.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        listOf(
            Triple(0, "المونتاج", Icons.Default.Tune),
            Triple(1, "الذكاء الاصطناعي", Icons.Default.Bolt),
            Triple(2, "موجات السينما", Icons.Default.Tv)
        ).forEach { (idx, label, icon) ->
            val isSelected = currentMode == idx
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isSelected) {
                            when (idx) {
                                0 -> PremiereBlue.copy(alpha = 0.2f)
                                1 -> NeonCyan.copy(alpha = 0.2f)
                                else -> PremiereOrange.copy(alpha = 0.2f)
                            }
                        } else Color.Transparent
                    )
                    .border(
                        BorderStroke(
                            1.dp,
                            if (isSelected) {
                                when (idx) {
                                    0 -> PremiereBlue
                                    1 -> NeonCyan
                                    else -> PremiereOrange
                                }
                            } else Color.Transparent
                        ),
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onModeChange(idx) }
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) {
                        when (idx) {
                            0 -> PremiereBlue
                            1 -> NeonCyan
                            else -> PremiereOrange
                        }
                    } else TextSecondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else TextSecondary
                )
            }
        }
    }
}

@Composable
fun PreviewMonitorWithCinemaScopes(
    uiState: EditorUiState,
    cinemaMode: Boolean,
    onTogglePlay: () -> Unit,
    onSeek: (Long) -> Unit
) {
    val duration = uiState.currentMedia?.durationMs ?: 120000L
    val progress = if (duration > 0) uiState.playheadMs.toFloat() / duration else 0f

    val infiniteTransition = rememberInfiniteTransition(label = "monitor_anim")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave"
    )

    // Build the dynamic ColorMatrix to show live color grading in the monitor!
    val filterMatrix = uiState.selectedFilter.matrix
    val liveColorMatrix = remember(filterMatrix, uiState.brightness, uiState.contrast, uiState.saturation, uiState.temperature, uiState.isAiColorizationEnabled, uiState.aiColorizationIntensity, uiState.aiColorizationVibrancy) {
        val result = if (uiState.isAiColorizationEnabled) {
            // Convert to base grayscale representation of B&W historic photo/video
            val bw = ColorMatrix().apply { setToSaturation(0f) }
            val colorize = ColorMatrix().apply {
                // Infuse beautiful neural color tones based on sliders
                val intense = uiState.aiColorizationIntensity
                val vibe = uiState.aiColorizationVibrancy
                set(0, 0, 1.15f * intense)
                set(1, 1, 1.0f * vibe)
                set(2, 2, 0.85f * intense)
                set(0, 4, 25f * intense)
                set(1, 4, 10f * vibe)
                set(2, 4, -5f * intense)
            }
            bw.apply { timesAssign(colorize) }
        } else {
            ColorMatrix(filterMatrix)
        }
        val brightnessMatrix = ColorMatrix().apply {
            setToScale(1f, 1f, 1f, 1f)
            set(0, 4, uiState.brightness * 255f)
            set(1, 4, uiState.brightness * 255f)
            set(2, 4, uiState.brightness * 255f)
        }
        val saturationMatrix = ColorMatrix().apply {
            setToSaturation(uiState.saturation)
        }
        val contrastMatrix = ColorMatrix().apply {
            val scale = uiState.contrast
            val translate = (-.5f * scale + .5f) * 255f
            set(0, 0, scale)
            set(1, 1, scale)
            set(2, 2, scale)
            set(0, 4, translate)
            set(1, 4, translate)
            set(2, 4, translate)
        }
        val tempMatrix = ColorMatrix().apply {
            set(0, 4, uiState.temperature * 50f)
            set(2, 4, -uiState.temperature * 50f)
        }
        result.apply {
            timesAssign(brightnessMatrix)
            timesAssign(contrastMatrix)
            timesAssign(saturationMatrix)
            timesAssign(tempMatrix)
        }
    }

    // Cinema Ambient Glow effect modifier
    val borderGlow = if (cinemaMode) {
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(12.dp),
                ambientColor = NeonCyan,
                spotColor = TrackVideoColor
            )
            .border(
                BorderStroke(2.dp, Brush.horizontalGradient(listOf(NeonCyan, TrackVideoColor))),
                RoundedCornerShape(12.dp)
            )
    } else {
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .border(BorderStroke(1.dp, SurfaceLight), RoundedCornerShape(12.dp))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        shape = RoundedCornerShape(12.dp),
        modifier = borderGlow
    ) {
        Column {
            // Monitor Header info bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceSlate)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(if (uiState.isPlaying) Color.Red else TextSecondary, CircleShape)
                    )
                    Text(
                        text = if (uiState.isPlaying) "بث سينمائي مباشر (نشط)" else "مراقبة الألوان والمعاينة",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (cinemaMode) {
                    Text(
                        text = "وضع السينما ومحلل الإشارة نشط 🎚️",
                        color = PremiereOrange,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = if (uiState.isAiUpscaleEnabled) "دقة عصبية فائقة: 8K AI (مفعّل)" else "دقة العرض: 4K UHD 60fps",
                        color = if (uiState.isAiUpscaleEnabled) NeonCyan else Color.White.copy(alpha = 0.8f),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (uiState.isAiUpscaleEnabled) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            // The Viewport showing our custom live graded vector graphics representation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color(0xFF07090C))
                    .testTag("preview_monitor"),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier.fillMaxSize()
                ) {
                    val w = size.width
                    val h = size.height

                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF020205), Color(0xFF090714), Color(0xFF140D26))
                        ),
                        size = size
                    )

                    // Calculate active rendering width based on aspect format
                    val aspectWidth = when (uiState.aspectFormat) {
                        "9:16" -> h * (9f / 16f)
                        "1:1" -> h * (1f / 1f)
                        "4:3" -> h * (4f / 3f)
                        else -> w // 16:9 full width
                    }
                    val startX = ((w - aspectWidth) / 2f).coerceAtLeast(0f)
                    val endX = (startX + aspectWidth).coerceAtMost(w)

                    clipRect {
                        // Clip the drawing paths inside the active aspect ratio frame!
                        clipRect(left = startX, right = endX) {
                            val horizonY = h * 0.65f

                            // 1. Synthwave Glowing Sun
                            val sunRadius = 40.dp.toPx()
                            val sunCenter = Offset(w * 0.5f, horizonY - 10.dp.toPx())
                            drawCircle(
                                brush = Brush.verticalGradient(
                                    colors = listOf(NeonPink, Color(0xFFFFD600))
                                ),
                                radius = sunRadius,
                                center = sunCenter,
                                colorFilter = ColorFilter.colorMatrix(liveColorMatrix)
                            )
                            // Draw horizontal scanlines through the sun (retro synthwave style)
                            val scanlineHeight = 3.dp.toPx()
                            val scanlineSpacing = 8.dp.toPx()
                            var lineY = sunCenter.y - sunRadius
                            while (lineY < sunCenter.y + sunRadius) {
                                // Only draw slit lines in the lower half of the sun, increasing in thickness
                                if (lineY > sunCenter.y - 10.dp.toPx()) {
                                    val factor = (lineY - (sunCenter.y - 10.dp.toPx())) / sunRadius
                                    val thickness = scanlineHeight * (0.8f + factor * 1.5f)
                                    drawRect(
                                        color = Color(0xFF090714),
                                        topLeft = Offset(sunCenter.x - sunRadius, lineY),
                                        size = Size(sunRadius * 2f, thickness)
                                    )
                                }
                                lineY += scanlineSpacing
                            }

                            // 2. Cyberpunk Skyline / Skyscrapers on Horizon
                            val buildingColors = listOf(Color(0xFF2C0F4D), Color(0xFF180A2B), Color(0xFF3B1566))
                            val buildings = listOf(
                                Triple(0.12f, 0.25f, 0.35f), // startX_ratio, width_ratio, height_ratio
                                Triple(0.28f, 0.18f, 0.45f),
                                Triple(0.42f, 0.22f, 0.28f),
                                Triple(0.6f, 0.2f, 0.4f),
                                Triple(0.75f, 0.15f, 0.32f)
                            )
                            buildings.forEachIndexed { i, b ->
                                val bWidth = w * b.second
                                val bHeight = h * b.third
                                val bX = startX + (endX - startX) * b.first - bWidth / 2f
                                val bY = horizonY - bHeight
                                drawRect(
                                    color = buildingColors[i % buildingColors.size],
                                    topLeft = Offset(bX, bY),
                                    size = Size(bWidth, bHeight),
                                    colorFilter = ColorFilter.colorMatrix(liveColorMatrix)
                                )
                                // Draw some neon window dots
                                val dotSize = 2.dp.toPx()
                                for (row in 1..4) {
                                    for (col in 1..3) {
                                        if ((row + col + i) % 3 != 0) {
                                            drawRect(
                                                color = if (i % 2 == 0) NeonCyan else NeonPink,
                                                topLeft = Offset(bX + bWidth * (col / 4f), bY + bHeight * (row / 6f)),
                                                size = Size(dotSize, dotSize)
                                            )
                                        }
                                    }
                                }
                            }

                            // 3. Cyberpunk Ground Perspective Grid
                            // Horizontal ground perspective lines
                            val gridLines = 8
                            for (gridI in 0..gridLines) {
                                val ratio = gridI.toFloat() / gridLines
                                val lineY = horizonY + (h - horizonY) * (ratio * ratio) // non-linear for depth
                                drawLine(
                                    color = NeonCyan.copy(alpha = 0.35f + ratio * 0.45f),
                                    start = Offset(startX, lineY),
                                    end = Offset(endX, lineY),
                                    strokeWidth = (1f + ratio * 1.5f).dp.toPx()
                                )
                            }
                            // Converging perspective lines from center horizon
                            val verticalGridLines = 10
                            for (gridI in 0..verticalGridLines) {
                                val ratio = gridI.toFloat() / verticalGridLines
                                val bottomX = startX + (endX - startX) * ratio
                                val topX = startX + (endX - startX) * (0.5f + (ratio - 0.5f) * 0.15f) // converge toward center
                                drawLine(
                                    color = NeonCyan.copy(alpha = 0.4f),
                                    start = Offset(topX, horizonY),
                                    end = Offset(bottomX, h),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }

                            // 4. Glowing flying cyberpunk vehicle/streak
                            val animOffset = waveOffset / 360f // 0.0 to 1.0
                            val carX = startX + (endX - startX) * animOffset
                            val carY = horizonY - 30.dp.toPx() - (Math.sin(animOffset * Math.PI * 2) * 15f).toFloat()
                            // Car glowing streak trail
                            drawCircle(
                                color = NeonPink,
                                radius = 3.dp.toPx(),
                                center = Offset(carX, carY)
                            )
                            drawLine(
                                color = NeonPink.copy(alpha = 0.6f),
                                start = Offset((carX - 25.dp.toPx()).coerceAtLeast(startX), carY),
                                end = Offset(carX, carY),
                                strokeWidth = 3.dp.toPx()
                            )
                            // Car outline
                            drawRect(
                                color = NeonCyan,
                                topLeft = Offset(carX - 8.dp.toPx(), carY - 3.dp.toPx()),
                                size = Size(10.dp.toPx(), 4.dp.toPx())
                            )

                            // 5. Playback tracker line overlay (current playback scrubber position)
                            val playheadX = startX + (endX - startX) * progress
                            drawLine(
                                color = Color.Red.copy(alpha = 0.9f),
                                start = Offset(playheadX, 0f),
                                end = Offset(playheadX, h),
                                strokeWidth = 2.dp.toPx()
                            )
                            drawCircle(
                                color = Color.Red,
                                radius = 6.dp.toPx(),
                                center = Offset(playheadX, 8.dp.toPx())
                            )
                        }

                        // Draw cropping overlay / letterboxing dark bars for pro camera vibe
                        if (startX > 0f) {
                            // Left dark pillar
                            drawRect(
                                color = Color.Black.copy(alpha = 0.75f),
                                topLeft = Offset(0f, 0f),
                                size = Size(startX, h)
                            )
                            // Right dark pillar
                            drawRect(
                                color = Color.Black.copy(alpha = 0.75f),
                                topLeft = Offset(endX, 0f),
                                size = Size(w - endX, h)
                            )
                            // Neon cyan cropping guides
                            drawLine(
                                color = NeonCyan.copy(alpha = 0.5f),
                                start = Offset(startX, 0f),
                                end = Offset(startX, h),
                                strokeWidth = 1.dp.toPx()
                            )
                            drawLine(
                                color = NeonCyan.copy(alpha = 0.5f),
                                start = Offset(endX, 0f),
                                end = Offset(endX, h),
                                strokeWidth = 1.dp.toPx()
                            )
                        }
                    }
                }

                // Subtitles & Text overlay style mapper
                if (uiState.overlayText.isNotEmpty()) {
                    val fontColor = when (uiState.overlayStyle) {
                        "CINEMATIC_YELLOW" -> Color(0xFFFFD54F)
                        "ALERT_RED" -> Color(0xFFFF5252)
                        else -> Color.White
                    }
                    val bgBrush = when (uiState.overlayStyle) {
                        "NEON_CYAN_BG" -> Color(0xFF00E5FF).copy(alpha = 0.35f)
                        "CINEMATIC_YELLOW" -> Color.Black.copy(alpha = 0.6f)
                        else -> Color.Transparent
                    }
                    val paddingValues = if (bgBrush != Color.Transparent) PaddingValues(horizontal = 12.dp, vertical = 6.dp) else PaddingValues(0.dp)
                    val shape = RoundedCornerShape(6.dp)

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = (200.dp * uiState.textPositionPercent).coerceIn(20.dp, 160.dp))
                            .clip(shape)
                            .background(bgBrush)
                            .padding(paddingValues)
                    ) {
                        Text(
                            text = uiState.overlayText,
                            color = fontColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }

                if (uiState.isSmartSilenceRemovalEnabled) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(Color.Red.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "تصفية الصمت AI نشط",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (uiState.selectedFilter != CinematicFilter.NONE) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .background(PremiereBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "تأثير: ${uiState.selectedFilter.arabicName}",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Overlay active aspect ratio display indicator
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(SurfaceSlate.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "الأبعاد: ${uiState.aspectFormat}",
                        color = NeonCyan,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // DYNAMIC RGB SIGNAL SCOPES (LUMETRI WAVEFORM SIMULATOR)
            if (cinemaMode) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0A0D14))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "لوحة تحليل الإشارة في الوقت الفعلي (Lumetri Waveform)",
                            color = TextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "R", color = Color.Red, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text(text = "G", color = Color.Green, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text(text = "B", color = NeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(55.dp)
                            .background(Color(0xFF04060A), RoundedCornerShape(4.dp))
                            .border(BorderStroke(0.5.dp, SurfaceLight), RoundedCornerShape(4.dp))
                    ) {
                        // Animated Oscilloscope Scopes
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val midY = h / 2f
                            
                            // Draw horizontal reference lines
                            drawLine(color = Color.White.copy(alpha = 0.1f), start = Offset(0f, h * 0.1f), end = Offset(w, h * 0.1f))
                            drawLine(color = Color.White.copy(alpha = 0.1f), start = Offset(0f, h * 0.5f), end = Offset(w, h * 0.5f))
                            drawLine(color = Color.White.copy(alpha = 0.1f), start = Offset(0f, h * 0.9f), end = Offset(w, h * 0.9f))
                            
                            val step = 4f
                            
                            // Generate pseudo-random signal jitter based on playhead and animation frame
                            for (x in 0 until w.toInt() step step.toInt()) {
                                val fx = x.toFloat()
                                val waveFactor = Math.sin((fx * 0.05f + waveOffset * 0.2f).toDouble()).toFloat()
                                val noiseFactor = Math.cos((fx * 0.3f - waveOffset * 0.5f).toDouble()).toFloat() * 6f
                                
                                val activeFactor = if (uiState.isPlaying) 1.5f else 0.1f
                                val yRed = midY - 4f + (waveFactor * 8f + noiseFactor) * activeFactor - (uiState.brightness * 15f)
                                val yGreen = midY + (waveFactor * 6f + noiseFactor * 0.8f) * activeFactor + (uiState.contrast * 5f) - 5f
                                val yBlue = midY + 4f + (waveFactor * 10f + noiseFactor * 1.2f) * activeFactor - (uiState.temperature * 12f)
                                
                                drawCircle(color = Color.Red.copy(alpha = 0.4f), radius = 1.dp.toPx(), center = Offset(fx, yRed.coerceIn(0f, h)))
                                drawCircle(color = Color.Green.copy(alpha = 0.4f), radius = 1.dp.toPx(), center = Offset(fx, yGreen.coerceIn(0f, h)))
                                drawCircle(color = NeonCyan.copy(alpha = 0.4f), radius = 1.dp.toPx(), center = Offset(fx, yBlue.coerceIn(0f, h)))
                            }
                        }
                    }
                }
            }

            // Monitor Playback & Scrubber Controls Toolbar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceSlate)
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Time scrubber slider
                Slider(
                    value = progress,
                    onValueChange = { ratio ->
                        onSeek((ratio * duration).toLong())
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp)
                        .testTag("monitor_scrubber"),
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = SurfaceLight
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Centered digital-style Time Display: "00:24 / 01:48"
                Text(
                    text = "${formatTime(uiState.playheadMs)} / ${formatTime(duration)}",
                    color = NeonCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(vertical = 2.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Playback Buttons Group styled like the terminal screenshot
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. REWIND SQUARE BUTTON
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .border(BorderStroke(2.dp, NeonCyan), RoundedCornerShape(8.dp))
                            .shadow(
                                elevation = 4.dp,
                                shape = RoundedCornerShape(8.dp),
                                ambientColor = NeonCyan,
                                spotColor = NeonCyan
                            )
                            .background(Color.Black)
                            .clickable { onSeek((uiState.playheadMs - 5000L).coerceAtLeast(0L)) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "تراجع ٥ ثواني",
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // 2. PLAY / PAUSE SQUARE BUTTON
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .border(BorderStroke(2.dp, NeonCyan), RoundedCornerShape(8.dp))
                            .shadow(
                                elevation = 6.dp,
                                shape = RoundedCornerShape(8.dp),
                                ambientColor = NeonCyan,
                                spotColor = NeonCyan
                            )
                            .background(Color.Black)
                            .clickable { onTogglePlay() }
                            .testTag("play_pause_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (uiState.isPlaying) "إيقاف مؤقت" else "تشغيل",
                            tint = NeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // 3. FAST FORWARD SQUARE BUTTON
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .border(BorderStroke(2.dp, NeonCyan), RoundedCornerShape(8.dp))
                            .shadow(
                                elevation = 4.dp,
                                shape = RoundedCornerShape(8.dp),
                                ambientColor = NeonCyan,
                                spotColor = NeonCyan
                            )
                            .background(Color.Black)
                            .clickable { onSeek((uiState.playheadMs + 5000L).coerceAtMost(duration)) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "تقديم ٥ ثواني",
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }
}



/**
 * Handles picking media and extracting metadata offline using MediaMetadataRetriever
 */
private fun retrieveMediaMetadata(
    context: Context,
    uri: Uri,
    onResult: (String, Boolean, Long, Long) -> Unit
) {
    try {
        var name = "مقطع_مستورد.mp4"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex != -1 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex)
            }
        }

        var isVideo = true
        var duration = 10000L // default fallback 10s
        var size = 0L

        context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
            size = afd.length
        }

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
            isVideo = hasVideo != null && hasVideo == "yes"
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            duration = durationStr?.toLong() ?: 10000L
        } catch (e: Exception) {
            // fallback if metadata retriever fails due to simulator sandbox
            isVideo = name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".mov")
        } finally {
            retriever.release()
        }

        onResult(name, isVideo, duration, size)
    } catch (e: Exception) {
        onResult("ملف_محلي_${System.currentTimeMillis().toString().takeLast(4)}", true, 60000L, 50 * 1024 * 1024L)
    }
}

/**
 * 1. File Selector & Source Info Panel Component
 */
@Composable
fun SourceFileSelector(
    metadata: MediaMetadata?,
    onPickFile: () -> Unit,
    onLoadDemo: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceSlate),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "مصدر الفيديو / الصوت الحالي",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Pick Actual File button
                    OutlinedButton(
                        onClick = onPickFile,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, PremiereBlue.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("import_media_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.UploadFile,
                            contentDescription = "استيراد",
                            modifier = Modifier.size(16.dp),
                            tint = NeonCyan
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "فتح ملف محلي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (metadata != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceLight, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (metadata.isVideo) TrackVideoColor.copy(alpha = 0.2f) else TrackAudioColor.copy(
                                    alpha = 0.2f
                                ),
                                RoundedCornerShape(8.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (metadata.isVideo) Icons.Default.VideoLibrary else Icons.Default.AudioFile,
                            contentDescription = "نوع الملف",
                            tint = if (metadata.isVideo) TrackVideoColor else TrackAudioColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = metadata.fileName,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = metadata.resolutionString,
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Box(
                                modifier = Modifier
                                    .size(3.dp)
                                    .background(TextSecondary, CircleShape)
                            )
                            Text(
                                text = metadata.format,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Column(
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = metadata.durationString,
                            color = PremiereOrange,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = metadata.sizeMbString,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            } else {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .background(SurfaceLight, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "الرجاء فتح ملف فيديو أو صوت للبدء في التعديل",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

/**
 * 2. Main Color Grading Monitor / Preview Screen Component
 */
@Composable
fun PreviewMonitor(
    uiState: EditorUiState,
    onTogglePlay: () -> Unit,
    onSeek: (Long) -> Unit
) {
    val duration = uiState.currentMedia?.durationMs ?: 120000L
    val progress = if (duration > 0) uiState.playheadMs.toFloat() / duration else 0f

    // Animated canvas vector design representing dynamic frames that grade colors in real-time
    val infiniteTransition = rememberInfiniteTransition(label = "monitor_anim")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave"
    )

    // Build the dynamic ColorMatrix to show live color grading in the monitor!
    val filterMatrix = uiState.selectedFilter.matrix
    val liveColorMatrix = remember(filterMatrix, uiState.brightness, uiState.contrast, uiState.saturation, uiState.temperature, uiState.isAiColorizationEnabled, uiState.aiColorizationIntensity, uiState.aiColorizationVibrancy) {
        val result = if (uiState.isAiColorizationEnabled) {
            // Convert to base grayscale representation of B&W historic photo/video
            val bw = ColorMatrix().apply { setToSaturation(0f) }
            val colorize = ColorMatrix().apply {
                // Infuse beautiful neural color tones based on sliders
                val intense = uiState.aiColorizationIntensity
                val vibe = uiState.aiColorizationVibrancy
                set(0, 0, 1.15f * intense)
                set(1, 1, 1.0f * vibe)
                set(2, 2, 0.85f * intense)
                set(0, 4, 25f * intense)
                set(1, 4, 10f * vibe)
                set(2, 4, -5f * intense)
            }
            bw.apply { timesAssign(colorize) }
        } else {
            ColorMatrix(filterMatrix)
        }
        
        // Custom brightness adjustment (row 0,1,2 offset indices 4, 9, 14 in raw float arrays, but here we can chain matrices)
        val brightnessMatrix = ColorMatrix().apply {
            setToScale(1f, 1f, 1f, 1f)
            // Apply brightness bias
            set(0, 4, uiState.brightness * 255f)
            set(1, 4, uiState.brightness * 255f)
            set(2, 4, uiState.brightness * 255f)
        }
        
        // Custom contrast and saturation adjustments
        val saturationMatrix = ColorMatrix().apply {
            setToSaturation(uiState.saturation)
        }

        val contrastMatrix = ColorMatrix().apply {
            val scale = uiState.contrast
            val translate = (-.5f * scale + .5f) * 255f
            set(0, 0, scale)
            set(1, 1, scale)
            set(2, 2, scale)
            set(0, 4, translate)
            set(1, 4, translate)
            set(2, 4, translate)
        }

        // Temperature matrix bias
        val tempMatrix = ColorMatrix().apply {
            set(0, 4, uiState.temperature * 50f) // Warm (Red bias)
            set(2, 4, -uiState.temperature * 50f) // Cool (Blue bias)
        }

        result.apply {
            timesAssign(brightnessMatrix)
            timesAssign(contrastMatrix)
            timesAssign(saturationMatrix)
            timesAssign(tempMatrix)
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SurfaceLight),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column {
            // Monitor Header info bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceSlate)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(if (uiState.isPlaying) Color.Red else TextSecondary, CircleShape)
                    )
                    Text(
                        text = if (uiState.isPlaying) "بث مباشر (معاينة)" else "شاشة العرض (متوقف)",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (uiState.isAiUpscaleEnabled) "دقة عصبية فائقة: 8K AI (مفعّل)" else "دقة العرض: 4K UHD 60fps",
                    color = if (uiState.isAiUpscaleEnabled) NeonCyan else Color.White.copy(alpha = 0.8f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (uiState.isAiUpscaleEnabled) FontWeight.Bold else FontWeight.Normal
                )
            }

            // The Viewport showing our custom live graded vector graphics representation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color(0xFF07090C))
                    .testTag("preview_monitor"),
                contentAlignment = Alignment.Center
            ) {
                // Vector landscape illustration styled dynamically by the ColorMatrix filter
                Canvas(
                    modifier = Modifier.fillMaxSize()
                ) {
                    val w = size.width
                    val h = size.height

                    // Draw Background Gradient
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF131A26), Color(0xFF080C14))
                        ),
                        size = size
                    )

                    // Clip to prevent drawing out of bounds
                    clipRect {
                        // Drawing moving layered mountain curves representing original high-fidelity video concepts
                        // We use direct drawing operations so the ColorFilter is applied beautifully!
                        
                        // Sun
                        drawCircle(
                            color = Color(0xFFFFB300),
                            radius = 45.dp.toPx(),
                            center = Offset(w * 0.7f, h * 0.4f),
                            colorFilter = ColorFilter.colorMatrix(liveColorMatrix)
                        )

                        // Far Mountains (animated)
                        val farPath = androidx.compose.ui.graphics.Path().apply {
                            moveTo(0f, h)
                            lineTo(0f, h * 0.65f)
                            quadraticTo(w * 0.25f, h * 0.55f + Math.sin(Math.toRadians(waveOffset.toDouble())).toFloat() * 10f, w * 0.5f, h * 0.7f)
                            quadraticTo(w * 0.75f, h * 0.8f + Math.cos(Math.toRadians(waveOffset.toDouble())).toFloat() * 10f, w, h * 0.6f)
                            lineTo(w, h)
                            close()
                        }
                        drawPath(
                            path = farPath,
                            color = Color(0xFF2A3B50),
                            colorFilter = ColorFilter.colorMatrix(liveColorMatrix)
                        )

                        // Near Hills (darker, high-contrast)
                        val nearPath = androidx.compose.ui.graphics.Path().apply {
                            moveTo(0f, h)
                            lineTo(0f, h * 0.8f)
                            quadraticTo(w * 0.35f, h * 0.72f, w * 0.65f, h * 0.85f)
                            quadraticTo(w * 0.85f, h * 0.9f, w, h * 0.75f)
                            lineTo(w, h)
                            close()
                        }
                        drawPath(
                            path = nearPath,
                            color = Color(0xFF141F2E),
                            colorFilter = ColorFilter.colorMatrix(liveColorMatrix)
                        )

                        // Draggable playback sweep scanner visual
                        val playheadX = w * progress
                        drawLine(
                            color = PremiereOrange.copy(alpha = 0.8f),
                            start = Offset(playheadX, 0f),
                            end = Offset(playheadX, h),
                            strokeWidth = 2.dp.toPx()
                        )
                        drawCircle(
                            color = PremiereOrange,
                            radius = 6.dp.toPx(),
                            center = Offset(playheadX, 10.dp.toPx())
                        )
                    }
                }

                // AI Silence indicators / Cut hints overlay (if enabled)
                if (uiState.isSmartSilenceRemovalEnabled) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(Color.Red.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "تصفية الصمت AI نشط",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Overlay active preset filter title tag
                if (uiState.selectedFilter != CinematicFilter.NONE) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .background(PremiereBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "تأثير: ${uiState.selectedFilter.arabicName}",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Monitor Playback & Scrubber Controls Toolbar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceSlate)
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Time scrubber slider
                Slider(
                    value = progress,
                    onValueChange = { ratio ->
                        onSeek((ratio * duration).toLong())
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .testTag("monitor_scrubber"),
                    colors = SliderDefaults.colors(
                        thumbColor = PremiereOrange,
                        activeTrackColor = PremiereOrange.copy(alpha = 0.7f),
                        inactiveTrackColor = SurfaceLight
                    )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Current Position Display
                    Text(
                        text = formatTime(uiState.playheadMs),
                        color = PremiereOrange,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Playback Buttons Group
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onSeek((uiState.playheadMs - 5000L).coerceAtLeast(0L)) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Replay5,
                                contentDescription = "تراجع ٥ ثواني",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // PLAY / PAUSE button with dynamic icon
                        FloatingActionButton(
                            onClick = onTogglePlay,
                            containerColor = PremiereBlue,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (uiState.isPlaying) "إيقاف مؤقت" else "تشغيل",
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        IconButton(
                            onClick = { onSeek((uiState.playheadMs + 5000L).coerceAtMost(duration)) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Forward5,
                                contentDescription = "تقديم ٥ ثواني",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Total Duration Display
                    Text(
                        text = formatTime(duration),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

/**
 * 3. Timeline Tracks Stack (Inspired by Adobe Premiere tracks)
 */
@Composable
fun TimelineTracks(
    uiState: EditorUiState,
    onSeek: (Long) -> Unit,
    onStartChange: (Long) -> Unit,
    onEndChange: (Long) -> Unit
) {
    val duration = uiState.currentMedia?.durationMs ?: 120000L
    val startRatio = uiState.selectionStartMs.toFloat() / duration
    val endRatio = uiState.selectionEndMs.toFloat() / duration
    val playheadRatio = uiState.playheadMs.toFloat() / duration

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "مخطط التايملاين (مسارات المونتاج والقص)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )
            
            // Selection range info
            Text(
                text = "النطاق المحدد: ${formatTime(uiState.selectionStartMs)} ⟷ ${formatTime(uiState.selectionEndMs)}  [${formatTime(uiState.selectionEndMs - uiState.selectionStartMs)}]",
                color = NeonCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Entire tracks box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceSlate, RoundedCornerShape(8.dp))
                .border(BorderStroke(1.dp, SurfaceLight), RoundedCornerShape(8.dp))
                .padding(vertical = 12.dp, horizontal = 16.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 1. Time code ticks ruler
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .drawBehind {
                            val w = size.width
                            val stepsCount = 10
                            for (i in 0..stepsCount) {
                                val x = w * (i.toFloat() / stepsCount)
                                val tickHeight = if (i % 2 == 0) 14f else 8f
                                drawLine(
                                    color = TextSecondary.copy(alpha = 0.5f),
                                    start = Offset(x, size.height - tickHeight),
                                    end = Offset(x, size.height),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }
                        }
                )

                // 2. VIDEO TRACK
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .background(SurfaceLight, RoundedCornerShape(4.dp))
                        .clip(RoundedCornerShape(4.dp))
                ) {
                    // Highlight selected region on the track
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(endRatio - startRatio)
                            .offset(x = (16.dp + (startRatio * 100f).dp)) // approximate visual layout offset simulation
                            .background(TrackVideoColor.copy(alpha = 0.75f))
                            .border(BorderStroke(1.dp, NeonCyan), RoundedCornerShape(4.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.VideoCameraFront,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "مسار الفيديو: V1",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // 3. AUDIO TRACK (A1 Original Sound)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .background(SurfaceLight, RoundedCornerShape(4.dp))
                        .clip(RoundedCornerShape(4.dp))
                ) {
                    // Highlight selected audio region
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(endRatio - startRatio)
                            .offset(x = (16.dp + (startRatio * 100f).dp))
                            .background(TrackAudioColor.copy(alpha = 0.75f))
                            .border(BorderStroke(1.dp, NeonCyan), RoundedCornerShape(4.dp))
                    ) {
                        // Drawing waveform lines inside audio track
                        Canvas(
                            modifier = Modifier.fillMaxSize()
                        ) {
                            val w = size.width
                            val h = size.height
                            val lines = 30
                            for (i in 0 until lines) {
                                val x = w * (i.toFloat() / lines)
                                val lineH = (Math.sin(i.toDouble() * 0.8) * (h * 0.3) + (h * 0.4)).toFloat()
                                drawLine(
                                    color = if (uiState.isOriginalAudioMuted) Color.White.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.3f),
                                    start = Offset(x, (h - lineH) / 2f),
                                    end = Offset(x, (h + lineH) / 2f),
                                    strokeWidth = 2.dp.toPx()
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (uiState.isOriginalAudioMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    tint = if (uiState.isOriginalAudioMuted) TextSecondary else Color.White.copy(alpha = 0.7f),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "مسار الصوت: A1 " + if (uiState.isOriginalAudioMuted) "(مكتوم 🔕)" else "",
                                    color = if (uiState.isOriginalAudioMuted) TextSecondary else Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 4. SECONDARY AUDIO TRACK (A2 Soundtrack Track)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .background(
                            if (uiState.soundtrack != "NONE") SurfaceLight else Color.Black.copy(alpha = 0.2f),
                            RoundedCornerShape(4.dp)
                        )
                        .clip(RoundedCornerShape(4.dp))
                        .border(
                            BorderStroke(
                                1.dp,
                                if (uiState.soundtrack != "NONE") NeonCyan.copy(alpha = 0.4f) else Color.Transparent
                            ),
                            RoundedCornerShape(4.dp)
                        )
                ) {
                    if (uiState.soundtrack != "NONE") {
                        // Drawing secondary waveform
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val lines = 36
                            for (i in 0 until lines) {
                                val x = w * (i.toFloat() / lines)
                                val lineH = (Math.cos(i.toDouble() * 1.1) * (h * 0.25) + (h * 0.35)).toFloat()
                                drawLine(
                                    color = NeonCyan.copy(alpha = 0.35f),
                                    start = Offset(x, (h - lineH) / 2f),
                                    end = Offset(x, (h + lineH) / 2f),
                                    strokeWidth = 1.5.dp.toPx()
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                val soundtrackLabel = when (uiState.soundtrack) {
                                    "CINEMATIC_EPIC" -> "موسيقى: سينمائي ملحمي 🎵"
                                    "LOFI_CHILL" -> "موسيقى: لو فاي هادئ ☕"
                                    "VLOG_HAPPY" -> "موسيقى: فلوق مبهج ✨"
                                    else -> "مسار الصوت الثانوي: A2"
                                }
                                Text(
                                    text = soundtrackLabel,
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Volume bubble indicator
                            Box(
                                modifier = Modifier
                                    .background(NeonCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "مستوى الصوت: ${(uiState.soundtrackVolume * 100).toInt()}%",
                                    color = NeonCyan,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        // Empty A2 Track placeholder
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddCircleOutline,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مسار الموسيقى والمؤثرات الصوتية: A2 (فارغ ⊕)",
                                color = TextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Draggable range sliders & Playhead layers overlay
            Canvas(
                modifier = Modifier
                    .matchParentSize()
                    .testTag("timeline_gesture_area")
            ) {
                val w = size.width

                // Draw orange playhead line
                val playheadX = w * playheadRatio
                drawLine(
                    color = PremiereOrange,
                    start = Offset(playheadX, 0f),
                    end = Offset(playheadX, size.height),
                    strokeWidth = 2.dp.toPx()
                )

                // Playhead top marker diamond
                val markerPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(playheadX - 6.dp.toPx(), 0f)
                    lineTo(playheadX + 6.dp.toPx(), 0f)
                    lineTo(playheadX, 8.dp.toPx())
                    close()
                }
                drawPath(path = markerPath, color = PremiereOrange)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Range Trim sliders
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceSlate, RoundedCornerShape(8.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.West,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "نقطة البداية (Start Cut): ${formatTime(uiState.selectionStartMs)}",
                    fontSize = 11.sp,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                Slider(
                    value = startRatio,
                    onValueChange = { onStartChange((it * duration).toLong()) },
                    modifier = Modifier
                        .width(160.dp)
                        .height(18.dp)
                        .testTag("selection_start_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan.copy(alpha = 0.5f),
                        inactiveTrackColor = SurfaceLight
                    )
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.East,
                    contentDescription = null,
                    tint = PremiereOrange,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "نقطة النهاية (End Cut): ${formatTime(uiState.selectionEndMs)}",
                    fontSize = 11.sp,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                Slider(
                    value = endRatio,
                    onValueChange = { onEndChange((it * duration).toLong()) },
                    modifier = Modifier
                        .width(160.dp)
                        .height(18.dp)
                        .testTag("selection_end_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = PremiereOrange,
                        activeTrackColor = PremiereOrange.copy(alpha = 0.5f),
                        inactiveTrackColor = SurfaceLight
                    )
                )
            }
        }
    }
}

data class CyberTool(val id: String, val arabicName: String, val icon: ImageVector, val tabIndex: Int)

/**
 * 4. Control Panels Tabbed Container
 */
@Composable
fun WorkspaceControlTabs(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel,
    selectedTabIdx: Int,
    onTabSelected: (Int) -> Unit,
    workspaceMode: Int
) {
    var showSpeedSlider by remember { mutableStateOf(false) }

    val tools = when (workspaceMode) {
        0 -> listOf(
            CyberTool("CUT", "القص والتقطيع", Icons.Default.ContentCut, 0),
            CyberTool("SPEED", "سرعة التشغيل", Icons.Default.Speed, -1),
            CyberTool("AUDIO", "موزع الصوت", Icons.Default.MusicNote, 3)
        )
        1 -> listOf(
            CyberTool("FX", "مساعد الذكاء", Icons.Default.AutoAwesome, 4),
            CyberTool("TEXT", "النصوص والترجمة", Icons.Default.TextFields, 2)
        )
        else -> listOf(
            CyberTool("FILTER", "فلاتر سينمائية", Icons.Default.ColorLens, 1),
            CyberTool("TRANS", "الضغط والتنسيق", Icons.Default.Tune, 5)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        // Speed slider card overlay when SPEED is clicked
        AnimatedVisibility(
            visible = showSpeedSlider,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceSlate),
                border = BorderStroke(1.dp, NeonPink.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "سرعة تشغيل المعاينة والتايملاين:",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${uiState.playbackSpeed}x",
                            color = NeonPink,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0.25f, 0.5f, 1.0f, 1.5f, 2.0f, 4.0f).forEach { speed ->
                            val isCurrentSpeed = uiState.playbackSpeed == speed
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isCurrentSpeed) NeonPink else SurfaceLight)
                                    .border(BorderStroke(1.dp, if (isCurrentSpeed) NeonPink else SurfaceLight.copy(alpha = 0.5f)), RoundedCornerShape(6.dp))
                                    .clickable { viewModel.updatePlaybackSpeed(speed) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${speed}x",
                                    color = if (isCurrentSpeed) Color.White else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Cyberpunk 7-tool Neon Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .border(BorderStroke(1.dp, Color(0xFF161B29)), RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tools.forEach { tool ->
                val label = tool.arabicName
                val icon = tool.icon
                val tabIdx = tool.tabIndex
                val isSelected = if (tabIdx == -1) showSpeedSlider else (selectedTabIdx == tabIdx && !showSpeedSlider)
                val color = if (isSelected) NeonPink else TextSecondary

                Column(
                    modifier = Modifier
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            if (tabIdx == -1) {
                                showSpeedSlider = !showSpeedSlider
                            } else {
                                showSpeedSlider = false
                                onTabSelected(tabIdx)
                            }
                        }
                        .testTag("cyber_tool_${tool.id}"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .shadow(
                                elevation = if (isSelected) 8.dp else 0.dp,
                                shape = CircleShape,
                                ambientColor = NeonPink,
                                spotColor = NeonPink
                            )
                            .border(BorderStroke(if (isSelected) 2.dp else 1.dp, color.copy(alpha = 0.8f)), CircleShape)
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = color,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = label,
                        color = color,
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        letterSpacing = 0.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Selected Tab Content Block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    SurfaceSlate,
                    RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
                )
                .border(
                    BorderStroke(1.dp, Color(0xFF161B29)),
                    RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
                )
                .padding(16.dp)
        ) {
            when (selectedTabIdx) {
                0 -> SplitControlView(uiState, viewModel)
                1 -> ColorGradingControlView(uiState, viewModel)
                2 -> TitlesSubtitlesControlView(uiState, viewModel)
                3 -> AudioMixerControlView(uiState, viewModel)
                4 -> LocalAiControlView(uiState, viewModel)
                5 -> CompressionControlView(uiState, viewModel)
            }
        }
    }
}

/**
 * Tab Content: 📝 Titles, Subtitles & Aspect Ratio Formatting View
 */
@Composable
fun TitlesSubtitlesControlView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Aspect Ratio Selector
        Text(
            text = "أبعاد ونسبة تقسيم شاشة الفيديو (Aspect Ratio):",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "16:9" to "أفلام (16:9) 🎬",
                "9:16" to "ريلز (9:16) 📱",
                "1:1" to "مربع (1:1) 🟩",
                "4:3" to "كلاسيكي (4:3) 📺"
            ).forEach { (format, label) ->
                val isSelected = uiState.aspectFormat == format
                Button(
                    onClick = { viewModel.updateAspectFormat(format) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) PremiereBlue else SurfaceLight
                    ),
                    border = BorderStroke(1.dp, if (isSelected) NeonCyan else Color.Transparent),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f).height(36.dp)
                ) {
                    Text(text = label, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        Divider(color = SurfaceLight)

        // Title text input
        Text(
            text = "تراكب النصوص والترجمة التلقائية (Live Text Overlay):",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        OutlinedTextField(
            value = uiState.overlayText,
            onValueChange = { viewModel.updateOverlayText(it) },
            placeholder = { Text("اكتب نصاً ليعرض فوق الفيديو...", color = TextSecondary, fontSize = 11.sp) },
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = Color.White),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                unfocusedContainerColor = Color.Black.copy(alpha = 0.1f),
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = SurfaceLight,
                cursorColor = NeonCyan
            ),
            modifier = Modifier.fillMaxWidth().testTag("overlay_text_input")
        )

        // Preset templates
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "قطع سينمائي مذهل 🎬" to "سينمائي",
                "تابعونا للمزيد! 🔔" to "دعوة للمتابعة",
                "بث مباشر بجودة 4K 🔥" to "بث مباشر"
            ).forEach { (presetText, label) ->
                SuggestionChip(
                    onClick = { viewModel.updateOverlayText(presetText) },
                    label = { Text(text = label, fontSize = 9.sp, color = NeonCyan) },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = SurfaceLight.copy(alpha = 0.5f)
                    ),
                    border = BorderStroke(1.dp, SurfaceLight)
                )
            }
        }

        Divider(color = SurfaceLight)

        // Custom Overlay style selector
        Text(
            text = "نمط ولون الخط التوضيحي:",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "CLASSIC_WHITE" to "أبيض كلاسيكي",
                "CINEMATIC_YELLOW" to "أصفر سينمائي",
                "NEON_CYAN_BG" to "تأثير نيون مضيء",
                "ALERT_RED" to "تنبيه أحمر"
            ).forEach { (style, label) ->
                val isSelected = uiState.overlayStyle == style
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) PremiereBlue.copy(alpha = 0.15f) else SurfaceLight
                    ),
                    border = BorderStroke(1.dp, if (isSelected) NeonCyan else Color.Transparent),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.updateOverlayStyle(style) }
                        .height(34.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = label, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Text Position slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "موضع النص الرأسي:", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(110.dp))
            Slider(
                value = uiState.textPositionPercent,
                onValueChange = { viewModel.updateTextPosition(it) },
                valueRange = 0.1f..0.9f,
                modifier = Modifier.weight(1f).testTag("text_position_slider"),
                colors = SliderDefaults.colors(thumbColor = NeonCyan)
            )
            Text(text = if (uiState.textPositionPercent < 0.4f) "أعلى" else if (uiState.textPositionPercent > 0.7f) "أسفل" else "منتصف", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
        }
    }
}

/**
 * Tab Content: 🎵 Soundtrack Mixer View
 */
@Composable
fun AudioMixerControlView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "إضافة مسار موسيقي خلفي (Soundtrack Mixer):",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "NONE" to ("صوت الفيديو الأصلي فقط" to "بدون إضافة أي موسيقى خلفية للمشهد"),
                "CINEMATIC_EPIC" to ("موسيقى سينمائية ملحمية 🎵" to "ألحان أوركسترالية حماسية هادئة للمقاطع الاحترافية"),
                "LOFI_CHILL" to ("أصوات لو فاي هادئة Lofi ☕" to "إيقاعات مريحة وهادئة مثالية للمدونات والشروحات"),
                "VLOG_HAPPY" to ("موسيقى فلوق مرحة ✨" to "ألحان إيجابية مفعمة بالنشاط والمرح لليوتيوب")
            ).forEach { (trackKey, data) ->
                val (title, desc) = data
                val isSelected = uiState.soundtrack == trackKey

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isSelected) PremiereBlue.copy(alpha = 0.15f) else SurfaceLight,
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            BorderStroke(1.dp, if (isSelected) NeonCyan else Color.Transparent),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { viewModel.updateSoundtrack(trackKey) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { viewModel.updateSoundtrack(trackKey) },
                        colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = desc,
                            fontSize = 8.sp,
                            color = TextSecondary,
                            lineHeight = 11.sp
                        )
                    }
                }
            }
        }

        if (uiState.soundtrack != "NONE") {
            Divider(color = SurfaceLight)

            // Volume adjustment
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "مستوى صوت الموسيقى:", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(110.dp))
                Slider(
                    value = uiState.soundtrackVolume,
                    onValueChange = { viewModel.updateSoundtrackVolume(it) },
                    valueRange = 0f..1f,
                    modifier = Modifier.weight(1f).testTag("soundtrack_volume_slider"),
                    colors = SliderDefaults.colors(thumbColor = NeonCyan)
                )
                Text(text = "${(uiState.soundtrackVolume * 100).toInt()}%", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
            }
        }

        Divider(color = SurfaceLight)

        // Original video audio controls (Mute / Unmute)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceLight, RoundedCornerShape(8.dp))
                .clickable { viewModel.toggleOriginalAudioMute(!uiState.isOriginalAudioMuted) }
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "كتم الصوت الأصلي للمقطع (Mute Original Sound)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "كتم صوت الحديث أو البيئة الأصلي للتركيز بالكامل على الموسيقى المضافة ومكساج الصوت الاحترافي.",
                    fontSize = 8.sp,
                    color = TextSecondary,
                    lineHeight = 11.sp
                )
            }
            Switch(
                checked = uiState.isOriginalAudioMuted,
                onCheckedChange = { viewModel.toggleOriginalAudioMute(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = NeonCyan,
                    checkedTrackColor = PremiereBlue
                ),
                modifier = Modifier.testTag("mute_original_switch")
            )
        }
    }
}

/**
 * Tab Content: ✂️ Cutting & Splitting View
 */
@Composable
fun SplitControlView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "تحديد أسلوب ونظام التقسيم",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // Split Mode Selector Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Manual/Current Range cut mode
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (uiState.splitMode == SplitMode.BY_PARTS) SurfaceLight else Color.Transparent
                ),
                border = BorderStroke(
                    1.dp,
                    if (uiState.splitMode == SplitMode.BY_PARTS) NeonCyan else SurfaceLight
                ),
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.updateSplitMode(SplitMode.BY_PARTS) }
                    .testTag("split_by_parts_card"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Dashboard,
                        contentDescription = null,
                        tint = if (uiState.splitMode == SplitMode.BY_PARTS) NeonCyan else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "تقسيم لقطع متساوية",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "تقطيع لمقاطع متساوية العدد",
                        fontSize = 9.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Fixed duration cut mode (WhatsApp / Stories)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (uiState.splitMode == SplitMode.BY_DURATION) SurfaceLight else Color.Transparent
                ),
                border = BorderStroke(
                    1.dp,
                    if (uiState.splitMode == SplitMode.BY_DURATION) NeonCyan else SurfaceLight
                ),
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.updateSplitMode(SplitMode.BY_DURATION) }
                    .testTag("split_by_duration_card"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.HourglassEmpty,
                        contentDescription = null,
                        tint = if (uiState.splitMode == SplitMode.BY_DURATION) NeonCyan else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "تقسيم بمدد زمنية محددة",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "مثالي لقصص انستغرام وواتساب",
                        fontSize = 9.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Divider(color = SurfaceLight)

        // Dynamic parameter adjustment based on selected mode
        if (uiState.splitMode == SplitMode.BY_PARTS) {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "عدد القطع المطلوب تقسيم المقطع إليها:",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "${uiState.partsCount} أجزاء متساوية",
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Slider(
                    value = uiState.partsCount.toFloat(),
                    onValueChange = { viewModel.updatePartsCount(it.toInt()) },
                    valueRange = 2f..24f,
                    steps = 21,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan
                    ),
                    modifier = Modifier.testTag("parts_count_slider")
                )
            }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "المدة الزمنية لكل قطعة:",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "${uiState.segmentDurationSec} ثانية لكل جزء",
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Presets buttons for duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        15 to "حالة واتساب (١٥ث)",
                        30 to "قصة انستغرام (٣٠ث)",
                        60 to "تيك توك ريلز (٦٠ث)"
                    ).forEach { (seconds, label) ->
                        Button(
                            onClick = { viewModel.updateSegmentDuration(seconds) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (uiState.segmentDurationSec == seconds) PremiereBlue else SurfaceLight
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                        ) {
                            Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Slider(
                    value = uiState.segmentDurationSec.toFloat(),
                    onValueChange = { viewModel.updateSegmentDuration(it.toInt()) },
                    valueRange = 5f..120f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan
                    ),
                    modifier = Modifier.testTag("duration_sec_slider")
                )
            }
        }

        // Live Grid Visualizer representing cutting boundaries
        Text(
            text = "المخطط الهيكلي للأجزاء المنتجة:",
            fontSize = 10.sp,
            color = TextSecondary
        )
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .background(Color.Black, RoundedCornerShape(6.dp))
                .padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            val totalSegments = if (uiState.splitMode == SplitMode.BY_PARTS) {
                uiState.partsCount
            } else {
                val mediaLenSec = (uiState.selectionEndMs - uiState.selectionStartMs) / 1000
                (mediaLenSec / uiState.segmentDurationSec).toInt().coerceAtLeast(1)
            }

            for (i in 0 until totalSegments.coerceAtMost(12)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    TrackVideoColor.copy(alpha = 0.5f),
                                    TrackVideoColor
                                )
                            ),
                            RoundedCornerShape(3.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${i + 1}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            if (totalSegments > 12) {
                Box(
                    modifier = Modifier
                        .width(30.dp)
                        .fillMaxHeight()
                        .background(SurfaceLight, RoundedCornerShape(3.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "+${totalSegments - 12}", color = NeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Tab Content: 🎨 Color Grading & Cinematic Filters View
 */
@Composable
fun ColorGradingControlView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الفلاتر السينمائية الاحترافية (بضغطة واحدة)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = "إعادة ضبط المستويات ⟲",
                fontSize = 11.sp,
                color = PremiereOrange,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { viewModel.resetColorGrading() }
            )
        }

        // Horizontal list of filters
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(CinematicFilter.values()) { filter ->
                val isSelected = uiState.selectedFilter == filter
                Card(
                    modifier = Modifier
                        .width(100.dp)
                        .clickable { viewModel.updateFilter(filter) }
                        .testTag("filter_card_${filter.name}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) PremiereBlue.copy(alpha = 0.2f) else SurfaceLight
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) NeonCyan else Color.Transparent
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Tiny representation box with gradient representing color matrix
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = when (filter) {
                                            CinematicFilter.NONE -> listOf(Color.Gray, Color.DarkGray)
                                            CinematicFilter.WARM_CINEMA -> listOf(Color(0xFFE29B00), Color(0xFF7C5601))
                                            CinematicFilter.TEAL_ORANGE -> listOf(Color(0xFF00BFA5), Color(0xFFFF6D00))
                                            CinematicFilter.NOIR -> listOf(Color.White, Color.Black)
                                            CinematicFilter.CYBERPUNK -> listOf(Color(0xFFD500F9), Color(0xFF00E5FF))
                                            CinematicFilter.COLD_THRILLER -> listOf(Color(0xFF0091EA), Color(0xFF002F6C))
                                        }
                                    )
                                )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = filter.arabicName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Divider(color = SurfaceLight)

        // Micro Adjustments
        Text(
            text = "المستويات والألوان التفصيلية (تحكم دقيق)",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )

        // Brightness Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "الإضاءة:", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(64.dp))
            Slider(
                value = uiState.brightness,
                onValueChange = { viewModel.updateColorGrading(it, uiState.contrast, uiState.saturation, uiState.temperature) },
                valueRange = -0.4f..0.4f,
                modifier = Modifier.weight(1f).testTag("brightness_slider"),
                colors = SliderDefaults.colors(thumbColor = NeonCyan)
            )
            Text(text = String.format("%+.1f", uiState.brightness * 10), fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
        }

        // Contrast Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "التباين:", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(64.dp))
            Slider(
                value = uiState.contrast,
                onValueChange = { viewModel.updateColorGrading(uiState.brightness, it, uiState.saturation, uiState.temperature) },
                valueRange = 0.5f..1.5f,
                modifier = Modifier.weight(1f).testTag("contrast_slider"),
                colors = SliderDefaults.colors(thumbColor = NeonCyan)
            )
            Text(text = String.format("%.1fx", uiState.contrast), fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
        }

        // Saturation Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "التشبع:", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(64.dp))
            Slider(
                value = uiState.saturation,
                onValueChange = { viewModel.updateColorGrading(uiState.brightness, uiState.contrast, it, uiState.temperature) },
                valueRange = 0.0f..2.0f,
                modifier = Modifier.weight(1f).testTag("saturation_slider"),
                colors = SliderDefaults.colors(thumbColor = NeonCyan)
            )
            Text(text = String.format("%.1fx", uiState.saturation), fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
        }

        // Temperature Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "الحرارة:", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(64.dp))
            Slider(
                value = uiState.temperature,
                onValueChange = { viewModel.updateColorGrading(uiState.brightness, uiState.contrast, uiState.saturation, it) },
                valueRange = -0.5f..0.5f,
                modifier = Modifier.weight(1f).testTag("temp_slider"),
                colors = SliderDefaults.colors(thumbColor = NeonCyan)
            )
            Text(text = if (uiState.temperature > 0) "دافئ" else if (uiState.temperature < 0) "بارد" else "طبيعي", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
        }
    }
}

/**
 * Tab Content: 🤖 Local AI Tools View
 */
@Composable
fun LocalAiControlView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(PremiereOrange.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "⚡", color = PremiereOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "مساعد المونتاج الذكي محلياً (بدون إنترنت)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Text(
            text = "تم بناء نظام ذكاء اصطناعي محلي يعمل بالكامل على نواة الأندرويد لتسريع معالجة ملفات 4K الفائقة وتقليل استخدام موارد المعالج والبطارية لتفادي ارتفاع حرارة الهاتف أثناء المونتاج.",
            fontSize = 11.sp,
            color = TextSecondary,
            lineHeight = 16.sp
        )

        Divider(color = SurfaceLight)

        // 1. Silence Remover AI
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceLight, RoundedCornerShape(8.dp))
                .clickable { viewModel.toggleSmartSilenceRemoval(!uiState.isSmartSilenceRemovalEnabled) }
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "تقطيع الصمت التلقائي (Silence Remover)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "تحليل الطيف الصوتي والتقطيع التلقائي للفراغات والصمت لتسريع إيقاع الفيديو والحديث.",
                    fontSize = 9.sp,
                    color = TextSecondary,
                    lineHeight = 13.sp
                )
            }
            Switch(
                checked = uiState.isSmartSilenceRemovalEnabled,
                onCheckedChange = { viewModel.toggleSmartSilenceRemoval(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = NeonCyan,
                    checkedTrackColor = PremiereBlue
                ),
                modifier = Modifier.testTag("silence_switch")
            )
        }

        // 2. Low CPU Export (Safety Cooling)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceLight, RoundedCornerShape(8.dp))
                .clickable { viewModel.toggleLowCpuExport(!uiState.isLowCpuExportEnabled) }
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "نظام التبريد الآمن (Cooling Mode)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(text = "موصى به لـ 4K", color = SuccessGreen, fontSize = 7.sp, fontWeight = FontWeight.Black)
                    }
                }
                Text(
                    text = "تنظيم كتابة الإطارات لمنع ارتفاع حرارة معالج الهاتف بنسبة ٤٥٪ وتمديد عمر البطارية أثناء عمليات التصدير الطويلة.",
                    fontSize = 9.sp,
                    color = TextSecondary,
                    lineHeight = 13.sp
                )
            }
            Switch(
                checked = uiState.isLowCpuExportEnabled,
                onCheckedChange = { viewModel.toggleLowCpuExport(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = NeonCyan,
                    checkedTrackColor = PremiereBlue
                ),
                modifier = Modifier.testTag("low_cpu_switch")
            )
        }

        // 3. AI Color Enhancer
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceLight, RoundedCornerShape(8.dp))
                .clickable { viewModel.toggleAiEnhance(!uiState.isAiEnhanceEnabled) }
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "ترميم وتفتيح الإطارات بالذكاء الاصطناعي",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "تحسين ألوان وظلال إطارات الفيديو ذات الإضاءة الضعيفة لزيادة التباين دون تبهيت الجوانب الطبيعية للمشهد.",
                    fontSize = 9.sp,
                    color = TextSecondary,
                    lineHeight = 13.sp
                )
            }
            Switch(
                checked = uiState.isAiEnhanceEnabled,
                onCheckedChange = { viewModel.toggleAiEnhance(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = NeonCyan,
                    checkedTrackColor = PremiereBlue
                ),
                modifier = Modifier.testTag("ai_enhance_switch")
            )
        }

        // 4. AI Super Resolution / Upscaling
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceLight, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().clickable { viewModel.toggleAiUpscale(!uiState.isAiUpscaleEnabled) }
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "رفع الدقة والوضوح (Super Resolution)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(NeonCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(text = "محلي 100%", color = NeonCyan, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "مضاعفة جودة الصور والفيديو ومعالجة البيكسلات الضبابية باستخدام شبكات عصبية مدمجة تضمن بقاء التفاصيل حادة دون استهلاك إنترنت.",
                        fontSize = 9.sp,
                        color = TextSecondary,
                        lineHeight = 13.sp
                    )
                }
                Switch(
                    checked = uiState.isAiUpscaleEnabled,
                    onCheckedChange = { viewModel.toggleAiUpscale(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonCyan,
                        checkedTrackColor = PremiereBlue
                    ),
                    modifier = Modifier.testTag("ai_upscale_switch")
                )
            }

            if (uiState.isAiUpscaleEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = DarkSlateBackground, thickness = 1.dp)
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "اختر طراز الذكاء الاصطناعي المحلي النشط:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                
                Spacer(modifier = Modifier.height(6.dp))
                
                val upscaleModels = listOf(
                    Triple("Real-ESRGAN Mobile 2x (Offline)", "١٢٠ ميجابايت • توازن فائق وثبات تفاصيل", "RAM: 1.4 GB"),
                    Triple("Super-SwinIR x4 (Offline)", "٢٥٠ ميجابايت • تفاصيل قصوى وإطارات ممتازة", "RAM: 2.1 GB"),
                    Triple("Mobile-SR Light (Offline)", "٤٥ ميجابايت • خفيف جداً ومثالي للهواتف القديمة", "RAM: 0.6 GB")
                )
                
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    upscaleModels.forEach { (modelName, details, ram) ->
                        val isSelected = uiState.aiUpscaleModel == modelName
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) NeonCyan.copy(alpha = 0.08f) else DarkSlateBackground,
                                    RoundedCornerShape(6.dp)
                                )
                                .border(
                                    BorderStroke(1.dp, if (isSelected) NeonCyan else Color.Transparent),
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { viewModel.updateAiUpscaleModel(modelName) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.updateAiUpscaleModel(modelName) },
                                colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = modelName.replace(" (Offline)", ""),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) NeonCyan else Color.White
                                )
                                Text(
                                    text = details,
                                    fontSize = 9.sp,
                                    color = TextSecondary
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .background(SurfaceLight, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = ram, color = TextSecondary, fontSize = 8.sp)
                            }
                        }
                    }
                }
            }
        }

        // 5. AI Colorization (تلوين الصور والفيديو)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceLight, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().clickable { viewModel.toggleAiColorization(!uiState.isAiColorizationEnabled) }
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "تلوين أبيض وأسود ذكي (AI Colorization)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(NeonPink.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(text = "بدون إنترنت", color = NeonPink, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "إعادة الحياة والتلوين الواقعي للقططات أو الصور القديمة ذات اللونين الأبيض والأسود بالاعتماد على شبكات التنبؤ اللوني محلياً.",
                        fontSize = 9.sp,
                        color = TextSecondary,
                        lineHeight = 13.sp
                    )
                }
                Switch(
                    checked = uiState.isAiColorizationEnabled,
                    onCheckedChange = { viewModel.toggleAiColorization(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonPink,
                        checkedTrackColor = PremiereBlue
                    ),
                    modifier = Modifier.testTag("ai_colorization_switch")
                )
            }

            if (uiState.isAiColorizationEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = DarkSlateBackground, thickness = 1.dp)
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "اختر طراز التلوين الشبكي المحلي النشط:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                
                Spacer(modifier = Modifier.height(6.dp))
                
                val colorModels = listOf(
                    Pair("DeOldify Lite (Offline)", "طراز عالي التوازن للأفلام التاريخية والوثائقية القديمة"),
                    Pair("Siggraph17 Mobile (Offline)", "طراز فائق الخفة ومثالي لصور الوجوه والأشخاص بدقة طبيعية"),
                    Pair("Chroma-Net v2 (Offline)", "تلوين فني مشبع وممتاز للمناظر الطبيعية واللقطات الخارجية")
                )
                
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    colorModels.forEach { (modelName, details) ->
                        val isSelected = uiState.aiColorizationModel == modelName
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) NeonPink.copy(alpha = 0.08f) else DarkSlateBackground,
                                    RoundedCornerShape(6.dp)
                                )
                                .border(
                                    BorderStroke(1.dp, if (isSelected) NeonPink else Color.Transparent),
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { viewModel.updateAiColorizationModel(modelName) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.updateAiColorizationModel(modelName) },
                                colors = RadioButtonDefaults.colors(selectedColor = NeonPink)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = modelName.replace(" (Offline)", ""),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) NeonPink else Color.White
                                )
                                Text(
                                    text = details,
                                    fontSize = 9.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                
                Text(
                    text = "مستويات موازنة الألوان الشبكية للنموذج:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                
                Spacer(modifier = Modifier.height(6.dp))

                // Intensity Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "كثافة التلوين:", fontSize = 10.sp, color = Color.White, modifier = Modifier.width(75.dp))
                    Slider(
                        value = uiState.aiColorizationIntensity,
                        onValueChange = { viewModel.updateAiColorizationIntensity(it) },
                        valueRange = 0.0f..2.0f,
                        modifier = Modifier.weight(1f).height(18.dp),
                        colors = SliderDefaults.colors(thumbColor = NeonPink, activeTrackColor = NeonPink.copy(alpha = 0.5f))
                    )
                    Text(text = String.format("%.1fx", uiState.aiColorizationIntensity), fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Vibrancy Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "حيوية الألوان:", fontSize = 10.sp, color = Color.White, modifier = Modifier.width(75.dp))
                    Slider(
                        value = uiState.aiColorizationVibrancy,
                        onValueChange = { viewModel.updateAiColorizationVibrancy(it) },
                        valueRange = 0.0f..2.0f,
                        modifier = Modifier.weight(1f).height(18.dp),
                        colors = SliderDefaults.colors(thumbColor = NeonPink, activeTrackColor = NeonPink.copy(alpha = 0.5f))
                    )
                    Text(text = String.format("%.1fx", uiState.aiColorizationVibrancy), fontSize = 10.sp, color = TextSecondary, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
                }
            }
        }
    }
}

/**
 * Tab Content: ⚡ Smart Compression & Export Parameters View
 */
@Composable
fun CompressionControlView(
    uiState: EditorUiState,
    viewModel: VideoEditorViewModel
) {
    val currentMedia = uiState.currentMedia
    val isImg = currentMedia?.isImage == true
    val isVid = currentMedia?.isVideo == true
    val isAud = currentMedia != null && !isImg && !isVid

    val origSizeMb = (currentMedia?.sizeBytes ?: 482344960L) / (1024.0 * 1024.0)

    // Calculate compression level ratio
    val compRatio = when (uiState.compressionLevel) {
        CompressionLevel.MAX -> 0.15
        CompressionLevel.BALANCED -> 0.45
        CompressionLevel.ULTRA_HQ -> 0.85
    }

    // Codec efficiency multiplier
    val codecBonus = when (uiState.targetCodec) {
        "AV1" -> 0.40  // AV1 is 60% more compressed than H.264
        "HEVC" -> 0.55 // HEVC is 45% more compressed than H.264
        else -> 1.0
    }

    // Resolution efficiency multiplier
    val resBonus = when (uiState.targetResolution) {
        "4K" -> 1.0
        "1080P" -> 0.35
        "720P" -> 0.18
        "480P" -> 0.08
        else -> 1.0 // Original
    }

    var finalSavingsMultiplier = compRatio * codecBonus
    if (isVid) {
        finalSavingsMultiplier *= resBonus
    }
    val targetMultiplier = finalSavingsMultiplier.coerceIn(0.05, 0.95)
    val expectedCompSizeMb = if (uiState.isCompressionEnabled) origSizeMb * targetMultiplier else origSizeMb

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Tab Header ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Transform,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "محول الصيغ ومحرك الضغط فائق الدقة",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Global compression switch
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (uiState.isCompressionEnabled) "الضغط مفعل" else "الضغط معطل",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Switch(
                    checked = uiState.isCompressionEnabled,
                    onCheckedChange = { viewModel.toggleCompression(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonCyan,
                        checkedTrackColor = PremiereBlue
                    ),
                    modifier = Modifier.testTag("compression_switch")
                )
            }
        }

        Text(
            text = "تعديل وضغط الملفات محلياً بنسبة تصل إلى 90% مع الحفاظ الكامل على الهوية البصرية وجودة الألوان والـ FPS وعمق الصوت، ودعم تحويل جميع صيغ الفيديو والصوت والصور.",
            fontSize = 11.sp,
            color = TextSecondary,
            lineHeight = 16.sp
        )

        if (isVid) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceLight, RoundedCornerShape(8.dp))
                    .border(
                        BorderStroke(1.dp, if (uiState.isCompressionEnabled && uiState.targetCodec == "HEVC") NeonCyan.copy(alpha = 0.5f) else Color.Transparent),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().clickable {
                        val currentlyActive = uiState.isCompressionEnabled && uiState.targetCodec == "HEVC"
                        if (currentlyActive) {
                            viewModel.toggleCompression(false)
                        } else {
                            viewModel.toggleCompression(true)
                            viewModel.updateTargetCodec("HEVC")
                        }
                    }
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "تفعيل ضغط H.265 (HEVC) فائق الجودة",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(NeonCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(text = "محلي 100%", color = NeonCyan, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = "تقليص مساحة التخزين بنسبة تصل إلى 90% مع الحفاظ المطلق على حدة التفاصيل، الألوان، الـ FPS وعمق الصوت باستخدام نواة الترميز المحلي المتطورة H.265 دون الحاجة للإنترنت.",
                            fontSize = 9.sp,
                            color = TextSecondary,
                            lineHeight = 13.sp
                        )
                    }
                    Switch(
                        checked = uiState.isCompressionEnabled && uiState.targetCodec == "HEVC",
                        onCheckedChange = { isChecked ->
                            if (isChecked) {
                                viewModel.toggleCompression(true)
                                viewModel.updateTargetCodec("HEVC")
                            } else {
                                viewModel.toggleCompression(false)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = PremiereBlue
                        ),
                        modifier = Modifier.testTag("hevc_compression_switch")
                    )
                }
            }
        }

        Divider(color = SurfaceLight)

        // --- SECTION 1: Local Format Conversion ---
        Text(
            text = "🔄 تحويل الصيغة والامتداد محلياً:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // Target formats list depending on currently loaded media
        val availableFormats = when {
            isImg -> listOf("WEBP", "PNG", "JPG", "HEIC", "BMP", "GIF")
            isVid -> listOf("MP4", "MKV", "MOV", "AVI", "WEBM", "FLV", "MP3", "WAV", "AAC") // Includes audio extraction!
            else -> listOf("MP3", "WAV", "AAC", "FLAC", "OGG", "AMR")
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = if (isVid) "اختر صيغة الإخراج المطلوبة (اختر صيغة صوتية لاستخراج الصوت من الفيديو):" else "اختر امتداد وصيغة الملف المستهدفة محلياً:",
                fontSize = 10.sp,
                color = TextSecondary
            )

            // Flowable grid of format chips
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                availableFormats.forEach { format ->
                    val isSelected = uiState.targetFormat == format
                    val isAudioExtraction = isVid && format in listOf("MP3", "WAV", "AAC")
                    
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) PremiereBlue.copy(alpha = 0.3f) else SurfaceLight,
                                RoundedCornerShape(8.dp)
                            )
                            .border(
                                BorderStroke(1.dp, if (isSelected) NeonCyan else Color.Transparent),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.updateTargetFormat(format) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = when {
                                    isAudioExtraction -> Icons.Default.MusicNote
                                    format in listOf("MP3", "WAV", "AAC", "FLAC", "OGG") -> Icons.Default.AudioFile
                                    format in listOf("PNG", "JPG", "WEBP", "BMP") -> Icons.Default.Image
                                    else -> Icons.Default.VideoLibrary
                                },
                                contentDescription = null,
                                tint = if (isSelected) NeonCyan else TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = format + if (isAudioExtraction) " (استخراج صوت)" else "",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) NeonCyan else Color.White
                            )
                        }
                    }
                }
            }
        }

        Divider(color = SurfaceLight)

        // --- SECTION 2: Advanced Compression Codecs ---
        if (uiState.isCompressionEnabled) {
            if (isVid && uiState.targetFormat !in listOf("MP3", "WAV", "AAC")) {
                Text(
                    text = "⚙️ ترميز الضغط المتقدم (Codec):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val codecs = listOf(
                        Triple("HEVC", "ترميز H.265 / HEVC", "توفير 45% إضافي + دقة 4K"),
                        Triple("AV1", "ترميز AV1 الحديث", "أقصى ضغط 60% + جودة فائقة"),
                        Triple("H264", "ترميز H.264 / AVC", "التوافق الكلي والسريع")
                    )

                    codecs.forEach { (codecKey, title, desc) ->
                        val isSelected = uiState.targetCodec == codecKey
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (isSelected) PremiereBlue.copy(alpha = 0.2f) else SurfaceLight,
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    BorderStroke(1.dp, if (isSelected) NeonCyan else Color.Transparent),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.updateTargetCodec(codecKey) }
                                .padding(10.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = title,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) NeonCyan else Color.White,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = desc,
                                    fontSize = 8.sp,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 10.sp
                                )
                            }
                        }
                    }
                }
                
                Divider(color = SurfaceLight)
            }

            // --- SECTION 3: Compression Quality Level Presets ---
            Text(
                text = "📊 مستوى ونسبة الضغط المطلوبة:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CompressionLevel.values().forEach { level ->
                    val isSelected = uiState.compressionLevel == level
                    
                    // Show custom small size multipliers
                    val savingsDesc = when (level) {
                        CompressionLevel.MAX -> "تصغير فائق للمساحة حتى 85% - مثالي لمواقع التواصل الاجتماعي"
                        CompressionLevel.BALANCED -> "توفير 55% من المساحة - جودة سينمائية فائقة وصور حادة"
                        CompressionLevel.ULTRA_HQ -> "توفير 15% من المساحة - الحفاظ على أعلى بت-ريت وبيكسلات سينمائية"
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isSelected) PremiereBlue.copy(alpha = 0.15f) else SurfaceLight,
                                RoundedCornerShape(8.dp)
                            )
                            .border(
                                BorderStroke(1.dp, if (isSelected) NeonCyan else Color.Transparent),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.updateCompressionLevel(level) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.updateCompressionLevel(level) },
                            colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = level.arabicName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = savingsDesc,
                                fontSize = 9.sp,
                                color = TextSecondary,
                                lineHeight = 12.sp
                            )
                        }
                    }
                }
            }

            Divider(color = SurfaceLight)

            // --- SECTION 4: Advanced Output Specifications ---
            Text(
                text = "⚙️ إعدادات الإخراج المتقدمة (اختياري):",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Resolution Selector (if video and not audio extraction)
                if (isVid && uiState.targetFormat !in listOf("MP3", "WAV", "AAC")) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "تغيير دقة الفيديو (Resolution):", fontSize = 10.sp, color = TextSecondary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val resolutions = listOf(
                                "ORIGINAL" to "الأصلية",
                                "4K" to "4K UHD",
                                "1080P" to "1080p FHD",
                                "720P" to "720p HD",
                                "480P" to "480p SD"
                            )
                            resolutions.forEach { (resKey, label) ->
                                val isResSelected = uiState.targetResolution == resKey
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (isResSelected) NeonCyan.copy(alpha = 0.2f) else SurfaceLight,
                                            RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            BorderStroke(1.dp, if (isResSelected) NeonCyan else Color.Transparent),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable { viewModel.updateTargetResolution(resKey) }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isResSelected) NeonCyan else Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // Audio Bitrate Selector (for audios and video)
                if (isVid || isAud) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "معدل بت الصوت (Audio Bitrate):", fontSize = 10.sp, color = TextSecondary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val bitrates = listOf(
                                "320" to "320 kbps (جودة الاستوديو)",
                                "192" to "192 kbps (جودة عالية متوازنة)",
                                "128" to "128 kbps (جودة مضغوطة قياسية)"
                            )
                            bitrates.forEach { (bitrateKey, label) ->
                                val isBitSelected = uiState.targetAudioBitrate == bitrateKey
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (isBitSelected) NeonCyan.copy(alpha = 0.2f) else SurfaceLight,
                                            RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            BorderStroke(1.dp, if (isBitSelected) NeonCyan else Color.Transparent),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable { viewModel.updateTargetAudioBitrate(bitrateKey) }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isBitSelected) NeonCyan else Color.White,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Frame Rate selector (for video)
                if (isVid && uiState.targetFormat !in listOf("MP3", "WAV", "AAC")) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "معدل الإطارات في الثانية (Frame Rate):", fontSize = 10.sp, color = TextSecondary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val fpsOptions = listOf("60", "30", "24")
                            fpsOptions.forEach { fps ->
                                val isFpsSelected = uiState.targetFps == fps
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (isFpsSelected) NeonCyan.copy(alpha = 0.2f) else SurfaceLight,
                                            RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            BorderStroke(1.dp, if (isFpsSelected) NeonCyan else Color.Transparent),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable { viewModel.updateTargetFps(fps) }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$fps FPS" + if (fps == "60") " (سلاسة فائقة)" else if (fps == "30") " (موفر)" else " (سينما)",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isFpsSelected) NeonCyan else Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // High Quality Color consistency switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceLight, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "تثبيت توازن ألوان HDR والكونسبت السينمائي",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "يمنع بهتان ألوان بكسلات الصور والفيديو الناتج عن عمليات الضغط المعتادة محلياً",
                            fontSize = 8.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = uiState.isHighQualityColorPreserved,
                        onCheckedChange = { viewModel.toggleHighQualityColorPreserved(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = PremiereBlue
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // --- SECTION 5: Live Compression Comparison Chart ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "المقارنة الرياضية والمساحة التخزينية المتوقعة:",
                        fontSize = 10.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الحجم الأصلي:",
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.width(90.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(10.dp)
                                .background(SurfaceLight, RoundedCornerShape(5.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(1f)
                                    .background(PremiereOrange, RoundedCornerShape(5.dp))
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = String.format("%.1f MB", origSizeMb),
                            color = PremiereOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(70.dp),
                            textAlign = TextAlign.End
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "بعد المعالجة والضغط:",
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.width(90.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(10.dp)
                                .background(SurfaceLight, RoundedCornerShape(5.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth((expectedCompSizeMb / origSizeMb).toFloat().coerceIn(0.01f, 1f))
                                    .background(SuccessGreen, RoundedCornerShape(5.dp))
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = String.format("%.1f MB", expectedCompSizeMb),
                            color = SuccessGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(70.dp),
                            textAlign = TextAlign.End
                        )
                    }

                    // Total Saved Space Tag
                    Box(
                        modifier = Modifier
                            .align(Alignment.End)
                            .background(SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        val savedPercent = (100 - (targetMultiplier * 100).toInt()).coerceIn(1, 99)
                        Text(
                            text = "مساحة تخزين مـوفـرة: $savedPercent% أقل من الأصلي بفضل تقنية ${uiState.targetCodec}!",
                            color = SuccessGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            // Disabled state warning
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(WarningYellow.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, WarningYellow.copy(alpha = 0.3f)), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = WarningYellow,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "الضغط معطل حالياً. سيتم تصدير وتحويل صيغة الملف محلياً دون ضغط وتقليص للمساحة التخزينية.",
                        color = Color.White,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

/**
 * 5. Fixed Bottom Export Action Bar Component
 */
@Composable
fun BottomExportBar(
    metadata: MediaMetadata?,
    onExportClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SurfaceSlate,
        tonalElevation = 8.dp,
        border = BorderStroke(1.dp, SurfaceLight),
        modifier = modifier
            .fillMaxWidth()
            .height(72.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "رابط إخراج المونتاج",
                    color = TextSecondary,
                    fontSize = 10.sp
                )
                Text(
                    text = "محلي ⟷ مجلد الاستوديو",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Central Export Button
            Button(
                onClick = onExportClick,
                enabled = metadata != null,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PremiereBlue,
                    contentColor = Color.White,
                    disabledContainerColor = SurfaceLight,
                    disabledContentColor = TextSecondary
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp),
                modifier = Modifier
                    .fillMaxHeight()
                    .testTag("export_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.OfflineBolt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "بدء التصدير السريع 4K",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * 6. Export Processing & Complete Progress Tracking Dialog Modal
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun ExportProgressDialog(
    uiState: EditorUiState,
    onDismiss: () -> Unit,
    onStartExport: () -> Unit,
    onChooseFolder: () -> Unit,
    onClearFolder: () -> Unit
) {
    val progress = uiState.progress

    Dialog(
        onDismissRequest = { if (!uiState.isProcessing) onDismiss() },
        properties = DialogProperties(
            dismissOnBackPress = !uiState.isProcessing,
            dismissOnClickOutside = !uiState.isProcessing,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceSlate),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SurfaceLight),
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uiState.isProcessing) "جاري المعالجة والتصدير..." else if (uiState.exportFinished) "اكتمل التصدير بنجاح! 🎉" else "تأكيد تصدير وقص الملف",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        if (!uiState.isProcessing) {
                            IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = TextSecondary)
                            }
                        }
                    }

                    Divider(color = SurfaceLight)

                    // Mode 1: Confirmation page before starting
                    if (!uiState.isProcessing && !uiState.exportFinished) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "سيقوم البرنامج بتقطيع وحفظ الملف محلياً بجودة فائقة السرعة اعتماداً على معالجات هاتف الأندرويد مباشرة، وبدون استهلاك للإنترنت.",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp,
                                textAlign = TextAlign.Center
                            )

                            // Quick metrics list
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SurfaceLight, RoundedCornerShape(8.dp))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(text = "صيغة المونتاج:", fontSize = 11.sp, color = TextSecondary)
                                    Text(text = "MP4 (MPEG-4 Container)", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(text = "الدقة المستهدفة:", fontSize = 11.sp, color = TextSecondary)
                                    Text(text = uiState.currentMedia?.resolutionString ?: "", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(text = "الفلتر السينمائي:", fontSize = 11.sp, color = TextSecondary)
                                    Text(text = uiState.selectedFilter.arabicName, fontSize = 11.sp, color = PremiereOrange, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(text = "أسلوب التقطيع:", fontSize = 11.sp, color = TextSecondary)
                                    Text(
                                        text = if (uiState.splitMode == SplitMode.BY_PARTS) "تقسيم لـ ${uiState.partsCount} قطع" else "تقسيم كل ${uiState.segmentDurationSec} ثانية",
                                        fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(text = "مستوى ضغط المساحة:", fontSize = 11.sp, color = TextSecondary)
                                    Text(
                                        text = if (uiState.isCompressionEnabled) uiState.compressionLevel.arabicName else "بدون ضغط الحجم",
                                        fontSize = 11.sp, color = SuccessGreen, fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Custom Target Export Folder Selector
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SurfaceLight, RoundedCornerShape(8.dp))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "مجلد الحفظ والتصدير المستهدف:",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val folderLabel = uiState.customExportFolderName ?: "الاستوديو الافتراضي (Movies/Qataa)"
                                    val folderIcon = if (uiState.customExportFolderUri != null) Icons.Default.FolderSpecial else Icons.Default.Folder
                                    
                                    Icon(
                                        imageVector = folderIcon,
                                        contentDescription = null,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    
                                    Text(
                                        text = folderLabel,
                                        fontSize = 11.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    
                                    Button(
                                        onClick = onChooseFolder,
                                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceSlate),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(28.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(text = "تغيير", fontSize = 10.sp, color = NeonCyan)
                                    }
                                    
                                    if (uiState.customExportFolderUri != null) {
                                        IconButton(
                                            onClick = onClearFolder,
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "مسح",
                                                tint = ErrorRed,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Button(
                                onClick = onStartExport,
                                colors = ButtonDefaults.buttonColors(containerColor = PremiereBlue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("start_processing_now_button")
                            ) {
                                Icon(imageVector = Icons.Default.OfflineBolt, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "تأكيد وبدء المعالجة والقص الفوري", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Mode 2: Loading State
                    if (uiState.isProcessing && progress != null) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Circular custom animated loading graphic
                            Box(
                                modifier = Modifier.size(90.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    progress = progress.percentage,
                                    strokeWidth = 6.dp,
                                    color = NeonCyan,
                                    trackColor = SurfaceLight,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "${(progress.percentage * 100).toInt()}%",
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "سرعة فائقة",
                                        color = SuccessGreen,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Active Step Description text
                            Text(
                                text = progress.currentStep,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )

                            // Traditional Horizontal Progress Bar (Requested)
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                LinearProgressIndicator(
                                    progress = progress.percentage,
                                    color = NeonCyan,
                                    trackColor = SurfaceLight,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp))
                                        .testTag("horizontal_progress_bar")
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "نسبة الإنجاز: ${(progress.percentage * 100).toInt()}%",
                                        fontSize = 10.sp,
                                        color = NeonCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "المعالج: محلي 100% 🔒",
                                        fontSize = 10.sp,
                                        color = SuccessGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Frame count and speed dashboard
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SurfaceLight, RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "الإطارات المعالجة", fontSize = 9.sp, color = TextSecondary)
                                    Text(
                                        text = "${progress.currentFrame} / ${progress.totalFrames}",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "سرعة معالجة الرندرة", fontSize = 9.sp, color = TextSecondary)
                                    Text(
                                        text = String.format("%.0f إطار/ثانية", progress.speedFps),
                                        color = SuccessGreen,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "حجم الملف المتولد", fontSize = 9.sp, color = TextSecondary)
                                    Text(
                                        text = String.format("%.1f MB", progress.outputSizeMb),
                                        color = PremiereOrange,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Cooling indicator
                            if (uiState.isLowCpuExportEnabled) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .background(SuccessGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.AcUnit, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                                    Text(text = "نظام تنظيم حرارة المعالج الذكي مفعّل ومستقر", color = SuccessGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Mode 3: Success Export State
                    if (uiState.exportFinished) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .background(SuccessGreen.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(36.dp)
                                )
                            }

                            Text(
                                text = "تمت عملية تقطيع وتصدير الفيديو بنجاح فائق!",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )

                            // Show list of generated files
                            Text(
                                text = "الملفات المحفوظة في ذاكرة الهاتف مباشرة:",
                                fontSize = 10.sp,
                                color = TextSecondary,
                                modifier = Modifier.align(Alignment.Start)
                            )

                            Column(
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                uiState.processedFiles.forEachIndexed { index, file ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(SurfaceLight, RoundedCornerShape(6.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.VideoFile,
                                                contentDescription = null,
                                                tint = NeonCyan,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = if (file.name.isNotEmpty()) file.name else "قطع_جزء_${index + 1}.mp4",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        Text(
                                            text = if (uiState.isCompressionEnabled) {
                                                String.format("%.1f MB (مضغوط)", (progress?.outputSizeMb ?: 15.0) / uiState.processedFiles.size)
                                            } else {
                                                "الحجم الأصلي دقة 4K"
                                            },
                                            color = SuccessGreen,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = onDismiss,
                                colors = ButtonDefaults.buttonColors(containerColor = PremiereBlue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("dismiss_success_dialog_button")
                            ) {
                                Text(text = "العودة لمساحة العمل والتايملاين", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
